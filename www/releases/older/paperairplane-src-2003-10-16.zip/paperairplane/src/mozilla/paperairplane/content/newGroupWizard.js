/** Initializes the "Choose a Group Name" step */
function initializeChooseAGroupNameStep() {
	selectDefaultDomainEnding();
	var groupNameField = document.getElementById("groupNameField");
	groupNameField.addEventListener("input", displayGroupName, false);
}

/** Selects ".group" to be the default domain ending in the "Choose a Group Name" step. */
function selectDefaultDomainEnding() {
	var menuList = document.getElementById("domainEndingField");
	var menuPopup = menuList.firstChild;
	var allMenuItems = menuPopup.childNodes;

	var index = 0;
	while (index < allMenuItems.length) {
		var currentMenuItem = allMenuItems.item(index);

		if (currentMenuItem.getAttribute("id") == "urn:paperairplane:domainendings:group") {
			break;
		}

		index++;
	}

	menuList.selectedIndex = index;
}

/** Displays what the current group name is in the "Choose a Group Name" step. */
function displayGroupName() {
	if (readyToDisplayGroupName()) {
		var generatedDomainNameContainer = document.getElementById("generatedDomainNameContainer");
		generatedDomainNameContainer.setAttribute("hidden", "false");
		
		var generatedDomainName = document.getElementById("generatedDomainName");
		generatedDomainName.value = getGroupName();
	}
	else {
		var generatedDomainNameContainer = document.getElementById("generatedDomainNameContainer");
		generatedDomainNameContainer.setAttribute("hidden", "true");
	}
}

/** Generates what the given group name is from the fields in the "Choose a Group Name" step. */
function getGroupName() {
	var domainEnding = document.getElementById("domainEndingField").value;
	var customDomainEnding = document.getElementById("customDomainEndingField").value;
	var groupNameBeginning = document.getElementById("groupNameField").value;

	var generatedName = groupNameBeginning;

	if (customDomainEnding.length > 0) {
		if (customDomainEnding[0] == ".") {
			generatedName += customDomainEnding;
		}
		else {
			generatedName += "." + customDomainEnding;
		}
	}
	else {
		generatedName += domainEnding;
	}

	return generatedName;
}

/** Determines if there is enough information yet in the fields to generate and display
    the group name in the "Choose a Group Name" step. */
function readyToDisplayGroupName() {
	var groupNameBeginning = document.getElementById("groupNameField").value;

	return groupNameBeginning.length != 0;
}