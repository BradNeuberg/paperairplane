package org.paperairplane;

/* - ***** BEGIN LICENSE BLOCK *****
   - Version: MPL 1.1/GPL 2.0/LGPL 2.1
   -
   - The contents of this file are subject to the Mozilla Public License Version
   - 1.1 (the "License"); you may not use this file except in compliance with
   - the License. You may obtain a copy of the License at
   - http://www.mozilla.org/MPL/
   -
   - Software distributed under the License is distributed on an "AS IS" basis,
   - WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
   - for the specific language governing rights and limitations under the
   - License.
   -
   - The Original Code is from Paper Airplane (http://www.paperairplane.us)
   -
   - The Initial Developer of the Original Code is Brad Neuberg.
   - Portions created by the Initial Developer are Copyright (C) 2003
   - the Initial Developer. All Rights Reserved.
   -
   - Contributor(s):
   -
   - Alternatively, the contents of this file may be used under the terms of
   - either the GNU General Public License Version 2 or later (the "GPL"), or
   - the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
   - in which case the provisions of the GPL or the LGPL are applicable instead
   - of those above. If you wish to allow use of your version of this file only
   - under the terms of either the GPL or the LGPL, and not to allow others to
   - use your version of this file under the terms of the MPL, indicate your
   - decision by deleting the provisions above and replace them with the notice
   - and other provisions required by the LGPL or the GPL. If you do not delete
   - the provisions above, a recipient may use your version of this file under
   - the terms of any one of the MPL, the GPL or the LGPL.
   -
   - ***** END LICENSE BLOCK *****
   */

import java.io.*;
import java.net.*;
import java.util.*;

import org.mortbay.util.*;
import org.mortbay.http.*;
import org.mortbay.p2psockets.util.*;
import org.mortbay.p2psockets.http.*;
import org.mortbay.jetty.*;
import org.mortbay.jetty.servlet.*;
import org.mortbay.http.handler.*;
import org.mortbay.servlet.*; 

import org.scache.*;

// commented out so that it will compile for now
//import net.jxta.*;
//import net.jxta.peergroup.*;

/** Provides a single facade for dealing with all interactions with the P2P Sockets, Java
	backend.  Makes it possible to sign into the network; makes it possible to start and 
	stop the local proxy (org.scache.P2PToWebProxy), and also makes it possible to create 
	and start groups. 
	
	A note on where Paper Airplane files are stored:
	Paper Airplane stores its configuration files in the user's home directory.
	All files are stored in the directory ".paperairplane".
	Inside of this directory are sub-directories, named for each of the accounts/usernames
	created, such as "Brad GNUBerg" and "HoangDinh".
	Inside each of these directories is a file named "myPaperAirplaneGroups.xml", which
	stores information about the Paper Airplane Groups this user has created so that they can be
	recreated and published on startup.
	Each group also has a sub-directory in this user account directory, named after the name of the
	group, such as "nike.laborpolicy" or "boobah.cat".  Inside of these sub-directories is the actual
	content for the group/web-site as accessing by the P2P version of Jetty.
  */

public class PaperAirplaneNetwork {
	/** The default port number to use for the local proxy. */
	public static int DEFAULT_LOCAL_PROXY_PORT = 9090;

	/** The unique name for our private P2P network. */
	public static String PEER_NETWORK_NAME = "Paper Airplane Network";

	/** The directory where all Paper Airplane preferences information is saved. */
	
	/** The filename where information about your groups is saved on disk. */
	public static String MY_GROUPS_PROPERTIES_FILE = "myPaperAirplaneGroups.xml";

	private String userName;
	private String password;
	
	protected int localProxyPort = DEFAULT_LOCAL_PROXY_PORT;
	protected String peerNetworkName = PEER_NETWORK_NAME;

	/** The user's home directory. */
	protected String usersHomeDirectory;

	/** This particular user's account sub-directory within the Paper Airplane directory. */
	protected String accountDirectory;

	/** A List of PaperAirplaneGroups that represent the groups
		this user has created. */
	protected List myGroups = new ArrayList();

	/** The P2P jetty web server that hosts the Paper Airplane Groups */
	protected Server groupEngine;

	/** The local proxy that proxies HTTP into and out of the P2P network */
	protected P2PToWebProxy localProxy;

	/** Creates a new account. */
	public void createAccount(String userName, String password) throws Exception {
		if (!usersHomeDirectory.endsWith(File.pathSeparator)) {
			usersHomeDirectory += File.pathSeparator;
		}

		accountDirectory = usersHomeDirectory + userName;

		// create this directory
		File account = new File(accountDirectory);
		account.mkdir();

		// generate the JXTA configuration information
		generatePeerConfiguration(userName, password);

		// sign in
		signIn(userName, password);
	}

	/** Signs into the Paper Airplane P2P network. */
	public void signIn(String userName, String password) throws Exception {
		// todo: finish
		// P2PNetwork.signin(
	}

	/** Starts the local proxy on the default port. */
	public void startLocalProxy() throws Exception {
	}

	/** Stops the local proxy. */
	public void stopLocalProxy() throws Exception {
	}

	/** Starts the P2P Jetty web server that hosts the Paper Airplane groups. */
	public void startGroupEngine() throws Exception {
	}

	/** Stops the P2P Jetty web server that hosts the Paper Airplane groups. */
	public void stopGroupEngine() throws Exception {
	}

	/** Stops the local proxy and the P2P web server hosting groups. */
	public void stopEverything() throws Exception {
		stopGroupEngine();
		stopLocalProxy();
	}
	
	/** Starts up any groups this user has created. */
	public void startMyGroups() throws Exception {
	}

	/** Creates and publishes a new group. */
	public void createNewGroup(PaperAirplaneGroup group) throws Exception {
	}

	/** Loads the list of groups from disk and returns a List of PaperAirplaneGroups */ 
	protected List loadMyGroups() throws Exception {
		// todo: finish
		return new ArrayList();
	}

	/** Saves the list of groups to disk  */ 
	protected void saveMyGroups(List myGroups) throws Exception {
		// todo: finish
		// String fileName = 
	}

	/** Generates this peers JXTA configuration information. */
	protected void generatePeerConfiguration(String userName, String password) throws Exception {
	}
}



	


