mainToolbar.swf and mainToolbar.html are in paperairplane/src/mozilla/paperairplane/content 
so that they can be accessed from the Mozilla chrome.  All ActionScript 2.0 classes are also located there.

11-24-03, Brad Neuberg