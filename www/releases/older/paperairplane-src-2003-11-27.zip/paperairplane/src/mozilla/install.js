/* -*- Mode: Javascript; tab-width: 2; c-basic-offset: 2; -*-
 * 
 * The contents of this file are subject to the Netscape Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/NPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is mozilla.org code.
 *
 * The Initial Developer of the Original Code is Netscape
 * Communications Corporation.  Portions created by Netscape are
 * Copyright (C) 1998 Netscape Communications Corporation. All
 * Rights Reserved.
 *
 * Contributor(s): 
 *
 *  Doug Turner   <dougt@acm.org> 
 *  Pete Collins  <petejc@mozdev.org> 
 *  Brad Neuberg <bkn3@columbia.edu>
 */

const VERSION             = "0.1";

var chromeDir = getFolder("Current User", "chrome");
var componentsDir = getFolder("Current User", "components");
var userDir = getFolder("Current User");
var tempDir = getFolder("Temporary");

var err = initInstall("Paper Airplane " + VERSION, "paperairplane", VERSION);
logComment("initInstall for Paper Airplane: " + err);

// todo: actually verify that there is enough space


// unpack all of the Paper Airplane chrome
err = addDirectory("Chrome",
				   VERSION,
				   "paperairplane",									// jar source folder                     
				   getFolder(chromeDir, "paperairplane"),			// target folder                     
				   "",												// target subdir                      
				   true);											// force flag   
				   
logComment("Added Paper Airplane chrome: " + err);

// register the content and skin chrome
registerChrome(CONTENT | DELAYED_CHROME, chromeDir, "paperairplane/content/"); 
registerChrome(SKIN | DELAYED_CHROME, chromeDir, "paperairplane/skin/");

// copy over all of the JAR files we need for the Java back-end
err = addDirectory("Components",
				   VERSION,
				   "lib",
				   getFolder(componentsDir, "paperairplane-libs"),
				   "",
				   true);
logComment("Copied over all JAR files into components/paperairplane: " + err);

// create the .paperairplane directory in the user's home directory where all profile and
// group pages are stored
getFolder("Current User", ".paperairplane");

// now modify the Java Plugin's BOOTCLASSPATH variable to point to and load our JARs
modifyJavaBootClassPath(userDir);

// actually perform the installation
err = getLastError();

if (err==SUCCESS) {
    performInstall();
	alert("Paper Airplane successfully installed.  Please restart your browser.");
}
else {
    cancelInstall(err);
}


/** ------------ Functions ------------ */ 

/** Modifies the Java Plug-Ins bootclasspath variable to load our Java JARS; we need to modify
	this variable because part of the P2P Sockets system (p2psockets.jxta.org), which Paper Airplane
	depends on, adds classes to java.net, which is a security violation unless we add them to the
	'boot class path'.
	
	To modify this variable, we have to load a special file named "properties" with the current
	Java version at the end, such as "properties141_05" for the JRE 1.4.1_05.  This file is stored
	in the user's home directory under the ".java" sub-directory, and stores configuration information
	for the Java Plug-In.  We add a special line to this file with the value "javaplugin.jre.params". */
function modifyJavaBootClassPath(userDir) {
	var tempDir = getFolder("Temporary");

	addFile("paperairplane", "modify_jre_properties.bat", tempDir, null);
	addFile("paperairplane", "ConfigureJRE.class", tempDir, null);
	addFile("paperairplane", "ConfigureJRE$1.class", tempDir, null);
	addFile("paperairplane", "ConfigureJRE$2.class", tempDir, null);
	logComment("Results of extracting modify_jre_properties.bat and ConfigureJRE.class: " + err);
	
	var modifyPropertiesScript = getFolder(tempDir, "modify_jre_properties.bat");
	// the extra spaces at the beginning get around some strange character encoding issues
	// when this string is sent to a Windows DOS shell; since JavaScript has no way to 
	// transform strings from one character encoding to another, and since we can't call XPCOM
	// from an XPInstall script, this is the only hack that works
	var userDirStr =  "     " + "\"" + userDir + "\"";

	/*err = File.execute(modifyPropertiesScript, userDirStr, true);
	logComment("Results of executing modify_jre_properties.bat: " + err);
	
	if (err) {
		alert("Paper Airplane could not be installed: " + err);
		logComment("Paper Airplane could not be installed: " + err);
		cancelInstall();
	}*/
}


// this function verifies disk space in kilobytes
function verifyDiskSpace(dirPath, spaceRequired)
{
   var spaceAvailable;
   // Get the available disk space on the given path
   spaceAvailable = fileGetDiskSpaceAvailable(dirPath);

   // Convert the available disk space into kilobytes
   spaceAvailable = parseInt(spaceAvailable / 1024);
   // do the verification
   if(spaceAvailable < spaceRequired)
   {
      logComment("Insufficient disk space: " + dirPath);
      logComment("  required : " + spaceRequired + " K");
      logComment("  available: " + spaceAvailable + " K");
      return(false);
   }
   return(true);
}
