/* - ***** BEGIN LICENSE BLOCK *****
   - Version: MPL 1.1/GPL 2.0/LGPL 2.1
   -
   - The contents of this file are subject to the Mozilla Public License Version
   - 1.1 (the "License"); you may not use this file except in compliance with
   - the License. You may obtain a copy of the License at
   - http://www.mozilla.org/MPL/
   -
   - Software distributed under the License is distributed on an "AS IS" basis,
   - WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
   - for the specific language governing rights and limitations under the
   - License.
   -
   - The Original Code is from Paper Airplane (http://www.paperairplane.us).
   -
   - The Initial Developer of the Original Code is Brad Neuberg
   - Portions created by the Initial Developer are Copyright (C) 2003
   - the Initial Developer. All Rights Reserved.
   -
   - Contributor(s):
   -
   - Alternatively, the contents of this file may be used under the terms of
   - either the GNU General Public License Version 2 or later (the "GPL"), or
   - the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
   - in which case the provisions of the GPL or the LGPL are applicable instead
   - of those above. If you wish to allow use of your version of this file only
   - under the terms of either the GPL or the LGPL, and not to allow others to
   - use your version of this file under the terms of the MPL, indicate your
   - decision by deleting the provisions above and replace them with the notice
   - and other provisions required by the LGPL or the GPL. If you do not delete
   - the provisions above, a recipient may use your version of this file under
   - the terms of any one of the MPL, the GPL or the LGPL.
   -
   - ***** END LICENSE BLOCK *****
   */

/** Initializes the sign on dialog */
function initializeSignOnDialog() {
	// get the OK button and change its label to be Sign On
	var dialog = document.getElementById("signOnDialog");
	var okButton = document.getAnonymousElementByAttribute(dialog, "dlgtype", "accept");
	okButton.setAttribute("label", "Sign On");
}

/** Called when the sign on button is pressed.
  * 
  * The network goes through the following steps:
  *		1. Initializizing Paper Airplane Network... - starts the JVM and loads the P2P Sockets libraries
  *		2. Contacting the Paper Airplane Network... - starts the P2P To Web Proxy
  *		3. Starting your Paper Airplane Groups... - starts the general P2P Tomcat server and the
  *		Paper Airplane servlets, and starts up a group servlet on your machine for each of your 
  *		groups.
  */
function doSignOn()
{
	// get what the user entered for their username and password
	var userName = document.getElementById("usernameField").value; 
	var password = document.getElementById("passwordField").value;

	// turn the username and password fields off, and turn on
	// the labels that indicate the network progress
	document.getElementById("fieldsAndStatusDeck").setAttribute("selectedIndex", 1);
	document.getElementById("proposedUserName").value = userName;
	document.getElementById("signOnDialog").setAttribute("mode", "contactingNetwork");
	
	// force any new height or width changes in the style rules for
	// mode=contactingNetwork to take place
	window.sizeToContent();

	// now start the operations that are needed to sign on
	initializePaperAirplaneNetwork();

	return false;
}

function initializePaperAirplaneNetwork() {
	var progressLabel = document.getElementById("progressLabel");
	progressLabel.value = "1. Initializing Paper Airplane Network..."; 

	var userName = document.getElementById('usernameField').value;
	var password = document.getElementById('passwordField').value;

	// we need to use the setTimeout function because otherwise the UI will not update before
	// running this slow operation; using setTimeout with a small timeout forces the UI to refresh
	// before running this slow operation

	window.setTimeout("startLocalProxy(document.getElementById('usernameField').value, " +
				      "document.getElementById('passwordField').value, processException); " +
					  "contactPaperAirplaneNetwork();", 1);
}

function contactPaperAirplaneNetwork() {
	var progressLabel = document.getElementById("progressLabel");
	progressLabel.value = "2. Contacting the Paper Airplane Network..."; 

	// we need to use the setTimeout function because otherwise the UI will not update before
	// running this slow operation; using setTimeout with a small timeout forces the UI to refresh
	// before running this slow operation
	window.setTimeout("startPaperAirplaneGroups();", 1);
}

function startPaperAirplaneGroups() {
	var progressLabel = document.getElementById("progressLabel");
	progressLabel.value = "3. Starting your Paper Airplane Groups...";

	// we need to use the setTimeout function because otherwise the UI will not update before
	// running this slow operation; using setTimeout with a small timeout forces the UI to refresh
	// before running this slow operation
	window.setTimeout("finishedSigningOn();", 1);
}

function finishedSigningOn() {
	var progressLabel = document.getElementById("progressLabel");
	progressLabel.value = "You are now signed in";

	// update what the username is
	var userName = document.getElementById("proposedUserName").value;
	var browserWindow = window.arguments[0];
	browserWindow.getElementById("userNameBroadcaster").value = userName;

	// remove the cancel button and add an OK button
	document.getElementById("networkProgressButtons").setAttribute("selectedIndex", 1);
}

/** Called when the user presses the Cancel button while signin on. */
function cancelSignOn() {
	alert("todo: should cancel here");
}

/** Figures out what to do based on the exception */
function processException(e) {
	alert("The following exception occured: " + e);
}