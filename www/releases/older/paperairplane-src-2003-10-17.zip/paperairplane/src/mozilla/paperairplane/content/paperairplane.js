/** For some reason, there are a couple of extra elements at the end of the toolbar that aren't coded
	into this file.  This is a hack to remove these elements from the end. */ 
function removeSpuriousElements() {
	var toolbar = document.getElementById("paperairplaneToolbar");
	var children = toolbar.childNodes;
	// keep scanning from the right until we hit a toolbarbutton
	var removeMe = new Array();
	for (var i = (children.length-1); children[i].nodeName != "toolbarbutton"; i--) {
		removeMe.push(children[i]);
	}
	for (var j = 0; j < removeMe.length; j++) {
		toolbar.removeChild(removeMe[j]);
	}
}

/** Toggles the Join Group/UnJoin Group button */
function toggleJoinUnjoinGroup() {
	var joinGroupButton = document.getElementById("joinGroupButton");
	var unjoinGroupButton = document.getElementById("unjoinGroupButton");
		var joinGroupButtonHidden = joinGroupButton.hidden;
	joinGroupButton.hidden = !joinGroupButtonHidden;
	unjoinGroupButton.hidden = joinGroupButtonHidden;
}

/** Toggles the Sign-On/Sign-Off button */
function toggleSignOnSignOff() {
	var signOnButton = document.getElementById("signOnButton");
	var signOffButton = document.getElementById("signOffButton");
		var signOnButtonHidden = signOnButton.hidden;
	signOnButton.hidden = !signOnButtonHidden;
	signOffButton.hidden = signOnButtonHidden;
}

/** Opens the New Group Wizard */
function showNewGroupWizard() {
	window.open("chrome://paperairplane/content/newGroupWizard.xul", "newGroupWizard", "chrome,dependent,centerscreen");
}

/** Opens the Sign On Dialog */
function showSignOnDialog() {
	window.openDialog("chrome://paperairplane/content/signOnDialog.xul","signon_dialog",
				  	  "chrome,dependent,centerscreen");
}