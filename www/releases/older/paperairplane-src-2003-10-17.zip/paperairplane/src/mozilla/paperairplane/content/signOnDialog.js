
/** Initializes the sign on dialog */
function initializeSignOnDialog() {
	// get the OK button and change it's label to be Sign On
	var dialog = document.getElementById("signOnDialog");
	var okButton = document.getAnonymousElementByAttribute(dialog, "dlgtype", "accept");
	okButton.setAttribute("label", "Sign On");
}

/** Called when the sign on button is pressed. */
function doSignOn()
{
  return true;
}
