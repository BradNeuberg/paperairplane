/** For some reason, there are a couple of extra elements at the end of the toolbar that aren't coded
	into this file.  This is a hack to remove these elements from the end. */ 
function removeSpuriousElements() {
	var toolbar = document.getElementById("paperairplaneToolbar");
	var children = toolbar.childNodes;
	// keep scanning from the right until we hit a toolbarbutton
	var removeMe = new Array();
	for (var i = (children.length-1); children[i].nodeName != "toolbarbutton"; i--) {
		removeMe.push(children[i]);
	}
	for (var j = 0; j < removeMe.length; j++) {
		toolbar.removeChild(removeMe[j]);
	}
}

/** Toggles the Join Group/UnJoin Group button */
function toggleJoinUnjoinGroup() {
	var joinGroupButton = document.getElementById("joinGroupButton");
	var unjoinGroupButton = document.getElementById("unjoinGroupButton");
		var joinGroupButtonHidden = joinGroupButton.hidden;
	joinGroupButton.hidden = !joinGroupButtonHidden;
	unjoinGroupButton.hidden = joinGroupButtonHidden;
}

/** Toggles the Sign-On/Sign-Off button */
function toggleSignOnSignOff() {
	var signOnButton = document.getElementById("signOnButton");
	var signOffButton = document.getElementById("signOffButton");
		var signOnButtonHidden = signOnButton.hidden;
	signOnButton.hidden = !signOnButtonHidden;
	signOffButton.hidden = signOnButtonHidden;
}

/** Opens the New Group Wizard */
function showNewGroupWizard() {
	window.open("chrome://paperairplane/content/newGroupWizard.xul", "newGroupWizard", "chrome,dependent,centerscreen");
}

/** Opens the Sign On Dialog */
function showSignOnDialog() {
	//window.open("chrome://paperairplane/content/signOnDialog.xul","signon_dialog",
	//			"chrome,dependent,centerscreen");

	doSignOn();
}

/** Called when the sign on button is pressed. */
function doSignOn()
{
	alert("doSignOn");
  window.openDialog("chrome://paperairplane/content/networkStatusDialog.xul","network_status",
				    "chrome,dependent,centerscreen",startSignIn,cancelSignIn,"Sign In Status");
}

function startSignIn(networkStatus) {
	alert("startSignIn");
	alert(networkStatus);
	networkStatus.updateProgress("0%", "Initializing Paper Airplane Network...");
	for (var i = 0; i < 5000; i++) {
	}

	networkStatus.updateProgress("20%", "Signing into Paper Airplane Network...");
	for (var i = 0; i < 5000; i++) {
	}

	networkStatus.updateProgress("40%", "Joining Paper Airplane Peer Group...");
	for (var i = 0; i < 5000; i++) {
	}

	networkStatus.finished("You are now signed in");
}

function cancelSignIn() {
}