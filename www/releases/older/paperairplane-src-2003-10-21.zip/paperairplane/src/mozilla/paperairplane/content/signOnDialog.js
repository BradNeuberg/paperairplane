
/** Initializes the sign on dialog */
function initializeSignOnDialog() {
	// get the OK button and change its label to be Sign On
	var dialog = document.getElementById("signOnDialog");
	var okButton = document.getAnonymousElementByAttribute(dialog, "dlgtype", "accept");
	okButton.setAttribute("label", "Sign On");
}

/** Called when the sign on button is pressed. */
function doSignOn()
{
	alert("doSignOn");
  window.openDialog("chrome://paperairplane/content/networkStatusDialog.xul","network_status",
				    "chrome,dependent,centerscreen",startSignIn,cancelSignIn,"Sign In Status");
}

function startSignIn(networkStatus) {
	alert("startSignIn");
	alert(networkStatus);
	networkStatus.updateProgress("0%", "Initializing Paper Airplane Network...");
	for (var i = 0; i < 50000; i++) {
	}

	networkStatus.updateProgress("20%", "Signing into Paper Airplane Network...");
	for (var i = 0; i < 50000; i++) {
	}

	networkStatus.updateProgress("40%", "Joining Paper Airplane Peer Group...");
	for (var i = 0; i < 50000; i++) {
	}

	networkStatus.finished("You are now signed in");
}

function cancelSignIn() {
}