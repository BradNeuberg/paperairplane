/** A reference to the singleton object that is passed to the caller of the
	Network Status Dialog.  See the documentation at the top of 
	networkStatusDialog.xul for details. */
var _networkStatusObject;

/** The function in the caller that will be called to start network operations. */
var _startFunction;

/** The function in the caller that will be called to cancel network operations. */
var _cancelFunction;

function initializeNetworkStatusDialog() {
	alert("initstart");
	// get the arguments passed in by the user
	_startFunction = window.arguments[0];
	_cancelFunction = window.arguments[1];
	var dialogTitle = window.arguments[2];

	// get references to the screen objects we want to manipulate
	var networkStatusDialog = document.getElementById("networkStatusDialog");
	var progressMeter = document.getElementById("progressMeter");
	var progressLabel = document.getElementById("progressLabel");

	// set the dialog to the string the user wants
	networkStatusDialog.setAttribute("title", dialogTitle);

	// create the network status object
	_networkStatusObject = new NetworkStatus(startFunction, cancelFunction, progressMeter, progressLabel);

	// start things
	_startFunction(_networkStatusObject);
	alert("initend");
}

function NetworkStatus(var progressMeter, var progressLabel) {
	this._progressMeter = progressMeter;
	this._progressLabel = progressLabel;
}

NetworkStatus.prototype = {
	var _progressMeter,
	var _progressLabel,
	/** Updates the network status dialog's progress meter to display the
	  *	given percentage done and displays the given progress label.
	  *	Call this if everything is going correctly with the network.
	  *	Example:
	  *	networkStatus.updateProgress("35%", "Contacting Rendezvous Server...")
	  */
	updateProgress: function(var percentageDone, var progressLabel) {
		_progressMeter.setAttribute("value", percentageDone);
		_progressLabel.setAttribute("value", progressLabel);
	},
	
	/** Call if a serious error occurs that requires canceling the progress.
	  *	The given error label will be displayed. */
	cancelProgress: function(var errorLabel) {
		_progressMeter.setAttribute("canceled", "true");
		_progressLabel.setAttribute("value", errorLabel);
		_progressLabel.setAttribute("cancel", "true");
	},

	/** Call when you are finished talking to the network. */
	finished: function(var finishedLabel) {
		_progressMeter.setAttribute("value", "100%");
		_progressLabel.setAttribute(finishedLabel);

		// todo: make a sound or force the dialog to regain focus
	}
}
	