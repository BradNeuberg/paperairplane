var _startFunction;
var _cancelFunction;

var networkStatus;

function initializeNetworkStatusDialog() {
	// get what the user wants this dialog to be called
	_startFunction = window.arguments[0];
	_cancelFunction = window.arguments[1];
	var dialogTitle = window.arguments[2];

	// get references to the screen objects we want to manipulate
	var networkStatusDialog = document.getElementById("networkStatusDialog");
	var groupBoxCaption = document.getElementById("groupBoxCaption");

	// set the dialog and group box caption to the string the user wants
	networkStatusDialog.setAttribute("title", dialogTitle);
	groupBoxCaption.setAttribute("label", dialogTitle);

	// below is a hack in order to be able to update the dialog
	// after it is already displaying
	networkStatus = new NetworkStatus();
	_startFunction(networkStatus);
	//window.setTimeout("_startFunction(networkStatus)", 1);
}

function NetworkStatus() {
	this._displayMeterOrFinished = document.getElementById("displayMeterOrFinished");
	this._progressMeter = document.getElementById("progressMeter");
	this._progressLabel = document.getElementById("progressLabel");
}

NetworkStatus.prototype = {
	/** Updates the network status dialog's progress meter to display the
	  *	given percentage done and displays the given progress label.
	  *	Call this if everything is going correctly with the network.
	  *	Example:
	  *	networkStatus.updateProgress("35%", "Contacting Rendezvous Server...")
	  */
	updateProgress: function(percentageDone, progressLabel) {
		this._progressMeter.value = percentageDone;
		this._progressLabel.value = progressLabel;
	},
	
	/** Call if a serious error occurs that requires canceling the progress.
	  *	The given error label will be displayed. */
	cancelProgress: function(errorLabel) {
		this._progressMeter.setAttribute("canceled", "true");
		this._progressLabel.value = errorLabel;
		this._progressLabel.setAttribute("cancel", "true");
	},

	/** Call when you are finished talking to the network. */
	finished: function(finishedLabel) {
		this._progressMeter.value = "100%";
		this._progressLabel.value = finishedLabel;

		this._displayMeterOrFinished.setAttribute("selectedIndex", 1);

		// todo: make a sound or force the dialog to regain focus
	}
}
	