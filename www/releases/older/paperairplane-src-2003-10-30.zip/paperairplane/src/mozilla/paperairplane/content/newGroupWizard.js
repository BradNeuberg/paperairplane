
/** --------------- Choose a Group Name step --------------- */

	/** Initializes the "Choose a Group Name" step */
	function initializeChooseAGroupNameStep() {
		selectDefaultDomainEnding();
		initializeTextFields();
	}

	/** The code below solves a strange issue that was occuring;
		when the "Choose a Group Name" step is first started, putting the focus
		into the group name field didn't show a cursor and failed to throw oninput events;
		the code below solves this. */
	function initializeTextFields() {
		var groupNameField = document.getElementById("groupNameField");
		groupNameField.focus(); // doesn't actually focus, just fixes bug

		var customDomainEnding = document.getElementById("customDomainEndingField");
		customDomainEnding.focus(); // focus away

		groupNameField.focus(); // now really focus back
	}

	/** Selects ".group" to be the default domain ending in the "Choose a Group Name" step. */
	function selectDefaultDomainEnding() {
		var menuList = document.getElementById("domainEndingField");
		var menuPopup = menuList.firstChild;
		var allMenuItems = menuPopup.childNodes;

		var index = 0;
		while (index < allMenuItems.length) {
			var currentMenuItem = allMenuItems.item(index);

			if (currentMenuItem.getAttribute("id") == "urn:paperairplane:domainendings:group") {
				break;
			}

			index++;
		}

		menuList.selectedIndex = index;
	}

	/** Displays what the current group name is in the "Choose a Group Name" step. */
	function displayGroupName() {
		maskNameFields();

		if (useCustomDomainEnding()) {
			// disable the domain ending pulldown
			var domainEnding = document.getElementById("domainEndingField");
			domainEnding.setAttribute("disabled", "true");
		}
		else {
			var domainEnding = document.getElementById("domainEndingField");
			domainEnding.setAttribute("disabled", "false");
		}	

		if (readyToDisplayGroupName()) {
			updateGeneratedNameLabel();
		}
		else {
			// hide the entire label that tells the user what their generate group name is
			var generatedDomainNameContainer = document.getElementById("generatedDomainNameContainer");
			generatedDomainNameContainer.setAttribute("hidden", "true");
		}
	}

	/** Generates what the given group name is from the fields in the "Choose a Group Name" step. */
	function getGroupName() {
		var domainEnding = document.getElementById("domainEndingField").value;
		var customDomainEnding = document.getElementById("customDomainEndingField").value;
		var groupNameBeginning = document.getElementById("groupNameField").value;

		var generatedName = groupNameBeginning;

		if (customDomainEnding.length > 0) {
			if (customDomainEnding[0] == ".") {
				generatedName += customDomainEnding;
			}
			else {
				generatedName += "." + customDomainEnding;
			}
		}
		else {
			generatedName += domainEnding;
		}

		return generatedName;
	}

	/** Determines if there is enough information yet in the fields to generate and display
		the group name in the "Choose a Group Name" step. */
	function readyToDisplayGroupName() {
		var groupNameBeginning = document.getElementById("groupNameField").value;

		return groupNameBeginning.length != 0;
	}

	/** Scans the group name and custom domain ending fields to remove incorrect characters. */
	function maskNameFields() {
		// Allowed characters are alphabetical characters, numbers, the underscore, and dashes
		var customDomainEndingField = document.getElementById("customDomainEndingField");
		var customDomainEnding = customDomainEndingField.value;

		var groupNameField = document.getElementById("groupNameField");
		var groupName = groupNameField.value;

		// \u0020 is the unicode number for the space character
		// \u002D is the unicode number for the dash character
		var correctCharsRegExp = new RegExp("[A-Za-z0-9_\u0020\u002D]*");

		customDomainEndingField.value = customDomainEnding.match(correctCharsRegExp);
		groupNameField.value = groupName.match(correctCharsRegExp);
	}

	/** Checks to see if a custom domain ending is a reserved, existing DNS domain ending
		and alerts the user if the ending is reserved. */
	function maskReservedDomainEndings() {
		var customDomainEndingField = document.getElementById("customDomainEndingField");
		var customDomainEnding = customDomainEndingField.value;

		var invalidName = false;
		/** Invalid names will simply fall through to the bottom */
		switch (customDomainEnding) {
			case "ad": case "aero": case "af": case "al": case "am": case "as": case "at": 
			case "au": case "az": case "ba": case "be": case "bg": case "biz": case "bm": 
			case "br": case "bt": case "by": case "ca": case "cc": case "ch": case "ck": 
			case "cn": case "com": case "coop": case "cx": case "cy": case "cz": case "de": 
			case "dk": case "dz": case "edu": case "ee": case "eg": case "es": case "fi": 
			case "fo": case "fr": case "ga": case "gb": case "ge": case "gf": case "gi": 
			case "gl": case "gm": case "gov": case "gr": case "gs": case "hk": case "hm": 
			case "hr": case "hu": case "id": case "ie": case "il": case "in": case "info": 
			case "int": case "io": case "is": case "it": case "jo": case "jp": case "kr": 
			case "kz": case "li": case "lk": case "lt": case "lu": case "lv": case "ly": 
			case "ma": case "mc": case "md": case "mil": case "mk": case "ms": case "mt": 
			case "museum": case "mx": case "name": case "net": case "nl": case "no": 
			case "nu": case "nz": case "org": case "pe": case "pk": case "pl": case "pr": 
			case "pro": case "pt": case "pw": case "ro": case "ru": case "se": case "sg": 
			case "sh": case "si": case "sk": case "sm": case "so": case "st": case "su": 
			case "tc": case "tf": case "th": case "tj": case "tm": case "tn": case "to": 
			case "tr": case "tw": case "ua": case "uk": case "us": case "va": case "ve": 
			case "vg": case "yu": case "za":
				invalidName = true;
				break;
			default:
				invalidName = false;
				break;
		}

		if (invalidName) {
			alert("." + customDomainEnding + " is a reserved domain ending for the existing World Wide Web"
				  + " and can not be used");
			customDomainEndingField.value = "";
		}			
	}

	/** Determines if a custom domain ending was entered */
	function useCustomDomainEnding() {
		var customDomainEndingField = document.getElementById("customDomainEndingField");
		var customDomainEnding = customDomainEndingField.value;

		return customDomainEnding.length != 0;
	}

	/** Makes the generated name label visible and generates its value from what
		the user has entered in the fields. */
	function updateGeneratedNameLabel() {
		var generatedDomainNameContainer = document.getElementById("generatedDomainNameContainer");
		generatedDomainNameContainer.setAttribute("hidden", "false");
		
		var generatedDomainName = document.getElementById("generatedDomainName");
		generatedDomainName.value = getGroupName();
	}