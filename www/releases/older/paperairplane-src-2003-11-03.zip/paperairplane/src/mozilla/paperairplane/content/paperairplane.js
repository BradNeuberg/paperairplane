/** For some reason, there are a couple of extra elements at the end of the toolbar that aren't coded
	into this file.  This is a hack to remove these elements from the end. */ 
function removeSpuriousElements() {
	var toolbar = document.getElementById("paperairplaneToolbar");
	var children = toolbar.childNodes;
	// keep scanning from the right until we hit a toolbarbutton
	var removeMe = new Array();
	for (var i = (children.length-1); children[i].nodeName != "toolbarbutton"; i--) {
		removeMe.push(children[i]);
	}
	for (var j = 0; j < removeMe.length; j++) {
		toolbar.removeChild(removeMe[j]);
	}
}

/** Sets whether the user is signed on. By doing so this will toggle the Sign-In/Sign-Off buttons correctly */
function setSignedOn(signedOn) {
	// toggle the signed on and signed off buttons as well as the broadcaster
	var signedOnBroadcaster = document.getElementById("signedOnBroadcaster");
	signedOnBroadcaster.setAttribute("signedOn", signedOn);
	if (signedOn) {
		signedOnBroadcaster.setAttribute("selectedIndex", 1);
	}
	else {
		signedOnBroadcaster.setAttribute("selectedIndex", 0);
	}

	// enable any functionality that is not site specific
	var notSiteSpecificBroadcasters = document.getElementById("notSiteSpecificBroadcasters");
	var children = notSiteSpecificBroadcasters.childNodes;
	for (var i = 0; i < children.length; i++) {
		var currentChild = children.item(i);
		currentChild.setAttribute("disabled", !signedOn);
	}
}

function isSignedOn() {
	return document.getElementById("signedOnBroadcaster").getAttribute("signedOn");
}

/** Opens the New Group Wizard */
function showNewGroupWizard() {
	window.open("chrome://paperairplane/content/newGroupWizard.xul", "newGroupWizard", "chrome,dependent,centerscreen");
}

/** Signs into the Paper Airpane network by opening the Sign On Dialog */
function signOn() {
	window.openDialog("chrome://paperairplane/content/signOnDialog.xul","signon_dialog",
					  "chrome,centerscreen,modal=yes", document);
	setSignedOn(true);
}

/** Signs off of the Paper Airplane network; disables the correct buttons in the toolbar */
function signOff() {
	setSignedOn(false);
}

