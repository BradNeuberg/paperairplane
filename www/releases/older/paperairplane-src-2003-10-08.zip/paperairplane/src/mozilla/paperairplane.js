user_pref("paperairplane.someProperty", "2");
user_pref("paperairplane.someBooleanProperty", true);

