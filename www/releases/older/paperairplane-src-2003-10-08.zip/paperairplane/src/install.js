/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is useragent toolbar.
 *
 * The Initial Developer of the Original Code is David Illsley.
 * Portions created by the Initial Developer are Copyright (C) 2001
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *  Andy Edmonds <aedmonds@mindspring.com>
 *  David Illsley <illsleydc@bigfoot.com>
 *  Pavol Vaskovic <pali@pali.sk>
 *  John Woods <johnrw@bestweb.net>
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 * ***** END LICENSE BLOCK ***** */

var locCountry="en-US";
var err, prefsAdded, errcode, oldPrefFile ;
var sysChrome = getFolder("chrome","googlebar");
var userChrome = getFolder("Current User","chrome");
var userChromeTarget = getFolder(userChrome,"googlebar");
var sysType = userType = bothType = installedBefore = false;
var ynUser = false;
var ynSys = false ;
var f1, f2, f3, f4 ; 	// get the root dir
var f5, f6, f7 ;		// then find /bin/chmod

const XPERRPAGE = "http://devedge.netscape.com/library/manuals/2001/xpinstall/1.0/err.html";
const OLDEST_BUILD_ID = 2003030700

initInstall("Googlebar", "/mozdev/googlebar", "0.7.0");
ggbres = loadResources("locale.inf");

logComment("Googlebar: initInstall: " + err);
prefsAdded = addThePrefs(); // see if we can write to the bin/default/pref folder

findOldInstallType();

//MAIN-1
if((newEnough()) && (sysType == false)) {
/*
newEnough	true if this browser is able to install extensions to the
				current user profile march 7 2003
sysType		true if a previous installation to the mozilla chrome
				folder by looking for a googlebar subfolder
*/

ynUser = confirm( ggbres.msgLine70 ); // ggbres.msgLine70=Ready to install for a SINGLE user to your personal settings folder?

if(ynUser) {
	prefsAdded = true; // We don't care about it now
	logComment("Googlebar: User selected Single-user install to user settings profile:\n\t "
				+ userChromeTarget);
	ynSys = false;
	err = RegisterIt("userProfile");
	}

	ynSys = false;
}

//MAIN-2
if( (ynUser == false) && (prefsAdded == true) && (userType == false) )
{
/*
ynUser		false when User selected not to install to the Current User profile
userType	true if a previous user profile was found, do not install to the Mozilla Chrome

prefsAdded	misnamed, should be canWeAddFiles or something.
			If we can't add a file, we can't install.
			Read only files on windows will break this, as I don't try to reset them
				because they shouldn't be there. to be continued
			Read only files do not disrupt root on my redhat. Mozilla overwrites them
				without needing any help, when root.
			Read only on the Apple osX so far hasn't worked, with Bernd's tests so far.
				Looks like more work before this will work.
*/

		ynSys = confirm( ggbres.msgLine100 ); // ggbres.msgLine100=Ready to install for ALL users of this system.
		if(ynSys)
			{
			logComment("Googlebar: User selected Multi-user install to system folder:\n\t ");
			err = RegisterIt("system");
			}
		else
			{
			logComment("Googlebar: Installer aborted installation.");
			err = USER_CANCELLED;
			}

}

//MAIN-3
if( prefsAdded == false){ // couldn't add the prefs file!
	alert( ggbres.msgLine116 + OLDEST_BUILD_ID ); // ggbres.msgLine116=It appears you do not have permissions for this type of install. \n Try to re-install to your Personal Settings Folder \n For that type of installation, you will need a version newer than:




	err = USER_CANCELLED ;
	cancelInstall();
}


// MAIN-4 (doTheDeed)
if( ( ynUser || ynSys ) && (err == SUCCESS) && (prefsAdded) )
{
/*
ynUser		User selected to install to the Current User profile
ynSys		User selected to install to the Mozilla Chrome
err			errors anywhere before this set this do not install flag, duh
prefsAdded	misnamed, should be canWeAddFiles or something.
			If we can't add a file, we can't install for all users on some platforms.
*/
logComment("Googlebar:\n\t ** Begin performInstall **\n\n");
err = performInstall();

		if ( err == SUCCESS )
		{
			if( (getPlatform()=='unix') && (ynSys == true))
				setupUnixAllowAll();

		       alert( ggbres.msgLine144 ); // ggbres.msgLine144=The Googlebar has been successfully installed. \n Please restart your browser to continue.


		       logComment("Googlebar:\n\t ** End performInstall **\n");
		}
		else
		{
		    alert( ggbres.msgLine151 + err); // ggbres.msgLine151=performInstall tried and failed.
			logComment("Googlebar: performInstall tried and failed. \n" + err);
		// Install switches follow
		logComment("ynUser:" + ynUser);
		logComment("ynSys:"  + ynSys);
		logComment("Previous Install All Users:" + sysType);
		logComment("Previous Install This User:" + userType);
		logComment("Previous Install Both User and System:" + bothType);
		logComment("Previous Install All installedBefore:" + installedBefore);
		logComment("Previous Install All prefsAdded:" + prefsAdded );
		logComment("Os Detected:" + getPlatform());
		logComment("New enough for profile install:" + newEnough());


		}

}
else
{
		// With a file missing, in the xpi, you can get here
		// User cancels wind up here too.
		// Install switches follow
		logComment("Googlebar: Install was cancelled, either by user or script.");
		logComment("ynUser:" + ynUser);
		logComment("ynSys:"  + ynSys);
		logComment("Previous Install All Users:" + sysType);
		logComment("Previous Install This User:" + userType);
		logComment("Previous Install Both User and System:" + bothType);
		logComment("Previous Install All installedBefore:" + installedBefore);
		logComment("Previous Install All prefsAdded:" + prefsAdded );
		logComment("Os Detected:" + getPlatform());
		logComment("New enough for profile install:" + newEnough());

		err = INSTALL_CANCELLED;
		cancelInstall(err);
}



//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////


function addThePrefs() {
// This is a non fatal write test to check write priveledge to the program folder
// On *nixes: root will pass, and users should fail. Most MS Windows everyone passes.
// *nix User installs should fail this, so no verbose alert msgs.

oldPrefFile=getFolder("Program", "defaults/pref/googlebar.js");
installedBefore = File.exists(oldPrefFile);

			logComment("Googlebar: checking for googlebar.js from a previous installation"
						+" returned:" + installedBefore + "\n");

errcode = addFile( "Googlebar Defaults",
			"0.5.0",
			"googlebar.js",
			getFolder("Program", "defaults/pref"),
			"googlebar.js",
			true);
			logComment("Googlebar: creating default prefs: "
						+"addFile returned:" + errcode );

if(errcode != SUCCESS) {

			logComment("Googlebar: There was a problem adding "
			+"the googlebar defaults to:"
			+getFolder("Program",
			"defaults/pref"));

		resetError();
		return false;
	}
	return true;
}


function setupUnixAllowAll() {

logComment("Googlebar: Attempting to set unix permissions for all users.\n ");

initInstall("Googlebar", "/mozdev/googlebar", "0.5.0");
ggbres = loadResources("locale.inf");
var arg1 = "-R u+rwx,go+r " + getFolder("Program", "chrome/googlebar" );
var arg2 = "ugo+rw " + getFolder("Program", "defaults/pref") + "googlebar.js";

f5 = getRootDir();
logComment("Googlebar: get RootDir returned " + f5);

if(f5 == DOES_NOT_EXIST) {
cancellInstall(DOES_NOT_EXIST);
return ;
}
	f6 = getFolder( f5, "bin");
		logComment("Googlebar: looking for 'bin', got\n" + f6 );
	f7 = getFolder( f6, "chmod");
		logComment("Googlebar: looking for chmod, got\n" + f7 );

		if(f7)
		{
			askUser = confirm( ggbres.msgLine251 ); // ggbres.msgLine251=Attempting to set the permissions up for ALL users \n select CANCEL to skip.

			if(askUser){
				err = File.execute(f7, arg1 );
				err = File.execute(f7, arg2 );
			}
			else
			err = USER_CANCELLED;
		}
		else
		{
			// no f7
			alert( ggbres.msgLine263 ); // ggbres.msgLine263=Couldn't find chmod in the /bin directory \n You will have to set those up permissions manually \n before restarting the browser.


			logComment("Googlebar: f1 was null.");
			err = INVALID_PATH_ERR;
		}


		if(err==SUCCESS)
		{
			err = performInstall();
			logComment("Googlebar: PerformInstall returned " + err );
			return true ;
		}
		else
		{

			logComment("Googlebar: PerformInstall returned " + err );
			cancelInstall(err);
			return false ;
		}

}


function showTheError() {
if(confirm( ggbres.msgLine289 ));  // ggbres.msgLine289=Would you like to point the browser to see the \n meaning of the XPInstall error code?

	window._content.document.location  = XPERRPAGE ;
}

function newEnough() {
	logComment("Googlebar: Host Build ID:" + buildID);
	if(buildID >= OLDEST_BUILD_ID)
	return true;
	else if( buildID == 0) //development versions
	return true;
	else
	return false;
	}

function getPlatform()
{
  var platformStr, platformNode;

  if('platform' in Install)
  {
    platformStr = new String(Install.platform);

    // Mac OS X (aka Darwin) is a real unix system
    if (!platformStr.search(/.*Darwin/))
      platformNode = 'unix';
    else if (!platformStr.search(/^Macintosh/))
      platformNode = 'mac';
    else if (!platformStr.search(/^Win/))
      platformNode = 'win';
    else if (!platformStr.search(/^OS\/2/))
      platformNode = 'win';
    else
      platformNode = 'unix';
  }
  else
  {
    var fOSMac  = getFolder("Mac System");
    var fOSWin  = getFolder("Win System");
    logComment("fOSMac: "  + fOSMac);
    logComment("fOSWin: "  + fOSWin);
    if(fOSMac != null)
      platformNode = 'mac';
    else if(fOSWin != null)
      platformNode = 'win';
    else
      platformNode = 'unix';
  }
  return platformNode;
}

function RegisterIt(installType)
{
if(installType == "system"){
var registerContFlag = CONTENT|DELAYED_CHROME ;
var registerLocFlag = LOCALE|DELAYED_CHROME ;
var registerTarget = sysChrome ;}

if(installType == "userProfile"){
var registerContFlag = CONTENT|PROFILE_CHROME ;
var registerLocFlag = LOCALE|PROFILE_CHROME ;
var registerTarget = userChromeTarget ;}

setPackageFolder(registerTarget);

err = addDirectory("googlebar");
logComment("Googlebar: Installation target:\n\t " + registerTarget + "\n");
logComment("Googlebar: addDirectory returned:" + err +"\n");

if ((err != SUCCESS) || (err != ALREADY_EXISTS))
  {
	err = registerChrome(registerContFlag,
						 getFolder(registerTarget, "content"));
		if ( err != SUCCESS )
		{
		    alert( ggbres.msgLine364 + err); // ggbres.msgLine364=Chrome registration failed when registering the \n content folder, with xpinstall error:


		    logComment("Googlebar: Installation failed registering"
		    		  +" content folder with error: " + err);

		    showTheError();
		    cancelInstall(err);
		    return err;
		}

	err = registerChrome(registerLocFlag,
						 getFolder(registerTarget,
						 "locale/" + locCountry + "/googlebar"));
		if ( err != SUCCESS )
		{
		    alert( ggbres.msgLine380 + err ); // ggbres.msgLine380=Chrome registration failed when registering \n the locale folder, with xpinstall error:


		    logComment("Googlebar: Installation failed registering"
		    		  +" locale folder with error: " + err);

		    showTheError();
		    cancelInstall(err);
		    return err;
		}

	else
	return SUCCESS ;

  }

else
  { // addDirectory failed

  	alert( ggbres.msgLine399 ); // ggbres.msgLine399=Failed to create directory. \n You probably don't have appropriate permissions

    logComment("Googlebar: addDirectory failed with error:" + err);
    cancelInstall(err);
    showTheError();
    return err;
  }

}


function getRootDir() {

logComment("Googlebar: get root directory\n ");

osRoot = getFolder("OS Drive");

logComment("Googlebar: getrootdir returning\n" + osRoot);
if(File.isDirectory(osRoot))
return osRoot;
else
return DOES_NOT_EXIST;

}

function findOldInstallType(){
// This function is where you control what happens up top.
// Set the allowable criteria for each type of install up top
// and decide if it is okay to do so down here. It evolved piecemeal
// when single-user installs were first possible. March/April 2003
// Me and my big mouth.

	sysType = false ;
	userType = false ;
	bothType = false ;
	installedBefore  = false ;

	logComment("Googlebar: Finding old Installation type\n");
	f1=getFolder("Chrome", "googlebar");
	f2=File.exists(f1);
	f3=File.exists(userChromeTarget);

	if(f2){ // Multi-user, better be the root user doing this

	sysType = true ;
	installedBefore  = true;
	logComment("Googlebar: Previously installed: systype " + sysType
				+ ":\n\t " + f1 + "\n" );
	}

	if(f3){ // Single-user
	userType = true ;
	installedBefore  = true;
	logComment("Googlebar: Previously installed: usertype " + userType
				+ ":\n\t " + userChromeTarget + "\n" );
	}

	if( f2 && f3 ){ // cannot proceed, cancel with msg
	sysType = true ;
	userType = true ;
	bothType = true ;
	installedBefore  = true;
	logComment("Googlebar: Previously installed: bothtypes:" + bothType
				+ "\n\t " + f1
				+ "\n\t " + userChromeTarget + "\n" );

	alert( ggbres.msgLine465 ); // ggbres.msgLine465=You have 2 previous googlebar installations \n one for ALL USERS of this system, and also one for \n THIS USER in your settings folder \n Cancelling Installation




	alert( ggbres.msgLine470 ); // ggbres.msgLine470=You should UNINSTALL the googlebar in your settings \n folder and try installing again.

	}

	if( (f2==false) && (f3==false) )
	{

	if(newEnough())
	{
	var OS = getPlatform();
	if(OS == "win"){
	sysType=confirm( ggbres.msgLine481 ); // ggbres.msgLine481=You have not installed googlebar before. The default installation \n TYPE in this case is for ALL USERS on this system. If this is ok then \n Click OK. If you want to install for a SINGLE USER click CANCEL.



		if(!sysType)
			userType=true;
		else
			userType=false;
	}

	if(OS == "unix"){
	userType=confirm( ggbres.msgLine492 ); // ggbres.msgLine492=You have not installed googlebar before. The default installation \n TYPE in this case is for a SINGLE user of this system. If this is ok then \n Click OK. If you want to install for ALL USERS click CANCEL.



		if(!userType)
			sysType=true;
		else
			sysType=false;
	}

	if(OS == "mac"){
	userType=confirm( ggbres.msgLine503 ); // ggbres.msgLine503=You have not installed Mozdev Googlebar before. \n The default installation TYPE in this case is for \n ALL users on this system. If this is ok then Click OK. \n If you want to install for a SINGLE USER click CANCEL.




		if(!userType)
			sysType=true;
		else
			sysType=false;
	}

	virginType = true ;
	installedBefore  = false ;
	logComment("Googlebar: Not Previously installed: choosing to install to:\n\t"
	+" ** Multi User:" +sysType+ "\n\t"
	+" ** Single User:" +userType+ "\n" );

	} // newEnough()

	else // !newEnough()
		{
		alert( ggbres.msgLine524 ); // ggbres.msgLine524=You have not installed the Mozdev Googlebar before. \n Your browser version only supports \n installing for ALL USERS of this system.



		sysType = true;
		userType = false;
		virginType = true;
		logComment("Googlebar: Not Previously installed: choosing to install to:\n\t"
		+" ** Multi User:" +sysType+ "\n\t"
		+" ** Single User:" +userType+ "\n" );
		}


  } // f2 = f3 = false

}



