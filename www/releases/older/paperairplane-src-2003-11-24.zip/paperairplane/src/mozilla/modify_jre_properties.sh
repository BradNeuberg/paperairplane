java -classpath "." ConfigureJRE $1


