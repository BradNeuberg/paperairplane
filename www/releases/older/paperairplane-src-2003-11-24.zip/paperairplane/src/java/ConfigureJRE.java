
import java.io.*;
import java.util.*;

/** This class modifies the Java Plugins property files to add
	a "-Xbootclasspath/a" directive for our Paper Airplane libraries.
	This is needed because Paper Airplane depends on P2P Sockets, which
	adds some custom classes to java.net (see p2psockets.jxta.org for details).

	To modify this variable, we have to load a special file named "properties" with the current
	Java version at the end, such as "properties141_05" for the JRE 1.4.1_05.  This file is stored
	in the user's home directory under the ".java" sub-directory, and stores configuration information
	for the Java Plug-In.  We add a special line to this file with the value "javaplugin.jre.params".

	@author Brad Neuberg, bkn3@columbia.edu
  */

public class ConfigureJRE {
	/** The version of the JRE that we are working with. */
	public static String JRE_VERSION = "1.4.1_02";

	/** The name of the JRE property that controls Java Plugin runtime parameters. */
	public static String JRE_RUNTIME_PARAMETERS_KEY = "javaplugin.jre.params";

	/** The name of the subdirectories under which our Paper Airplane JARs are located. */
	public static String JARS_LOCATION = "components" + File.separator + "paperairplane-libs" + File.separator;

	/** The first argument should be the path to the Mozilla/FireBird 'home directory'
		for this user, such as 
		"C:\Documents and Settings\BradNeuberg\Application Data\Phoenix\Profiles\Default\2ujtnf3q.slt".  
		Our JARs are inside of a subdirectory in there named 'components/paperairplane-libs'. */
	public static void main(String args[]) {
		try {
			// figure out where our Paper Airplane JARs are located
			if (args.length < 1) {
				throw new RuntimeException("The first argument to ConfigureJRE must "
										  + "be the location of the user's Mozilla home directory");
			}

			// setup what the bootclasspath addition will look like
			String userDir = handleUserDir(args[0]);
			String jarFiles = getJARList(userDir);
			String bootClassPath = "-Xbootclasspath/a=\"" + jarFiles + "\"";

			// figure out where the .java directory is
			String usersJavaDirName = getUsersJavaDir();

			String propFiles[] = getPropertyFiles(usersJavaDirName);
			for (int i = 0; i < propFiles.length; i++) {
				handlePropertiesFile(usersJavaDirName + File.separator + propFiles[i], bootClassPath);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	/** Formats and fixes the user directory argument passed in by Mozilla. */
	protected static String handleUserDir(String userDir) {
		// sometimes a trailing quote gets passed through on Windows
		if (userDir.charAt(userDir.length() - 1) == '\"') {
			userDir = userDir.substring(0, userDir.length() - 1);
		}

		if (userDir.charAt(userDir.length() - 1) != File.separatorChar) {
			userDir += File.separator;
		}

		return userDir;
	}

	/** Enumerates and sets up the full path to each of the JARs Paper Airplane depends
		on, formatted for appending to the bootclasspath. */
	protected static String getJARList(String userDir) throws FileNotFoundException, IOException {
		String jarDirName = userDir + JARS_LOCATION;
		File jarDir = new File(jarDirName);
		if (jarDir.exists() == false) {
			throw new RuntimeException(jarDirName + " does not exist!");
		}

		// enumerate the JARs we are dealing with
		FilenameFilter jarFilter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if (name.indexOf(".jar") == -1) {
					return false;
				}
				else {
					return true;
				}
			}
		};
		String jarFilesList[] = jarDir.list(jarFilter); 
		String jarFiles = "";
		for (int i = 0; i < (jarFilesList.length-1); i++) {
			jarFiles += jarDirName + jarFilesList[i] + File.pathSeparator;
		}
		jarFiles += jarDirName + jarFilesList[jarFilesList.length-1];

		return jarFiles;
	}

	/** Returns the file names for each of the Java Plugin properties files in the user's
		.java directory, such as "properties141_02". */
	protected static String[] getPropertyFiles(String usersJavaDirName)
			throws FileNotFoundException, IOException {
		File usersJavaDir = new File(usersJavaDirName);
		FilenameFilter propFiles = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if (name.startsWith("properties")) {
					return true;
				}
				else {
					return false;
				}
			}
		};	

		return usersJavaDir.list(propFiles);
	}

	/** Returns a String object to the current user's .java directory. */
	protected static String getUsersJavaDir() throws FileNotFoundException, IOException {
		String userDir = System.getProperty("user.home");
		String usersJavaDirName = userDir + File.separator + ".java";
		File usersJavaDir = new File(usersJavaDirName);
		if (usersJavaDir.exists() == false) {
			throw new RuntimeException(usersJavaDir + " does not exist!");
		}

		return usersJavaDirName;
	}

	/** Determines what the filename for the Java PlugIn properties file should be,
		based on the JRE version we are using. */
	protected static String getJavaPluginPropertiesFileName(String usersJavaDirName) {
		// strip out the dashes from our JRE_VERSION variable
		StringTokenizer tk = new StringTokenizer(JRE_VERSION, ".", false);
		StringBuffer results = new StringBuffer();
		while (tk.hasMoreTokens()) {
			results.append(tk.nextToken());
		}
		String filenameEnding = results.toString();

		return "properties" + filenameEnding;
	}

	/** Loads, modifies for the bootclasspath variable, and then saves the 
	    property file for the given filename. */
	protected static void handlePropertiesFile(String fileName, String bootClassPath) 
			throws FileNotFoundException, IOException {
		// load the properties file we are looking for into a java.util.Properties object
		Properties pluginProps = new Properties();
		pluginProps.load(new FileInputStream(fileName));

		// is there already a value for JRE_RUNTIME_PARAMETERS_KEY?
		if (pluginProps.containsKey(JRE_RUNTIME_PARAMETERS_KEY)) {
			String existingValue = pluginProps.getProperty(JRE_RUNTIME_PARAMETERS_KEY);
			// see if we've already installed Paper Airplane before by scanning for paperairplane.jar;
			// in this case we'll have to wipe out the existing JRE parameters; this could
			// mess up someones custom values, unfortunately.
			if (existingValue.toLowerCase().indexOf("paperairplane.jar") == -1) { // first time
				existingValue += " " + bootClassPath;
				pluginProps.put(JRE_RUNTIME_PARAMETERS_KEY, existingValue);
			}
			else {
				pluginProps.put(JRE_RUNTIME_PARAMETERS_KEY, bootClassPath);
			}
		}
		// no existing value
		else { 
			pluginProps.put(JRE_RUNTIME_PARAMETERS_KEY, bootClassPath);
		}

		// save the properties file
		pluginProps.store(new FileOutputStream(fileName), "");
	}
}
