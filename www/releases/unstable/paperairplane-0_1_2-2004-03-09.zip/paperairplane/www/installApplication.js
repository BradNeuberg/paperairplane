/**
   - ***** BEGIN LICENSE BLOCK *****
   - Version: MPL 1.1/GPL 2.0/LGPL 2.1
   -
   - The contents of this file are subject to the Mozilla Public License Version
   - 1.1 (the "License"); you may not use this file except in compliance with
   - the License. You may obtain a copy of the License at
   - http://www.mozilla.org/MPL/
   -
   - Software distributed under the License is distributed on an "AS IS" basis,
   - WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
   - for the specific language governing rights and limitations under the
   - License.
   -
   - The Original Code is from Paper Airplane (http://www.paperairplane.us)
   -
   - The Initial Developer of the Original Code is Brad Neuberg.
   - Portions created by the Initial Developer are Copyright (C) 2003
   - the Initial Developer. All Rights Reserved.
   -
   - Contributor(s):
   -
   - Alternatively, the contents of this file may be used under the terms of
   - either the GNU General Public License Version 2 or later (the "GPL"), or
   - the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
   - in which case the provisions of the GPL or the LGPL are applicable instead
   - of those above. If you wish to allow use of your version of this file only
   - under the terms of either the GPL or the LGPL, and not to allow others to
   - use your version of this file under the terms of the MPL, indicate your
   - decision by deleting the provisions above and replace them with the notice
   - and other provisions required by the LGPL or the GPL. If you do not delete
   - the provisions above, a recipient may use your version of this file under
   - the terms of any one of the MPL, the GPL or the LGPL.
   -
   - ***** END LICENSE BLOCK *****
   */

/** The scripts below help to install Java-based XUL applications including the Java Runtime
  * Environment if it is not yet installed.  It also checks to make sure the user is running
  * a browser needed by your application, and if they already have Java installed, if it
  * is the correct version of Java needed for your application.
  *
  * To configure, change the static variables below as appropriate for your application,
  * and call installApplication() from the hyperlink you want users to click to install
  * the app. 
  * 
  * Currently, automatic background installation of the Java Runtime are only supported
  * for Windows.  Users will be directed to the appropriate Java download
  * page for Mac, Solaris, and Linux since silent installation is not supported for these platforms
  * yet (wanna submit an XPI file for these platforms or others then visit java.mozdev.org/java_xpis).
  *
  * The script also installs JSLib (jslib.mozdev.org).
  *
  * @author Brad Neuberg, bkn3@columbia.edu
  */

/** The application that is being installed */
var APP_NAME = "Paper Airplane";

/** The application version that is being installed */
var APP_VERSION = "0.1.2";

/** What is displayed to the user in the XPInstall dialog when they try to install this software. */
var APP_IDENTIFIER = APP_NAME + " " + APP_VERSION;

/** The application's XPI file */
var APP_XPI = "paperairplane.xpi";

/** Whether this application supports Mozilla (not including FireBird) */
var SUPPORTS_MOZILLA = false;

/** Whether this application supports FireBird */
var SUPPORTS_FIREBIRD = true;

/** The version of Java that must be installed (this or greater). **/
var JAVA_VERSION = "1.4.1";

/** The version of Flash that must be installed (this or greater). **/
var FLASH_VERSION = "7.0";

/** Whether this application only supports this given Java version, and not any that
    are higher (i.e. even if the user has a JRE of a higher version, this version will
	still be installed). */
var ONLY_SUPPORTS_THIS_JAVA_VERSION = false;

/** Whether this application only supports this given Flash version, and not any that
    are higher (i.e. even if the user has the Flash plugin of a higher version, this version will
	still be installed). */
var ONLY_SUPPORTS_THIS_FLASH_VERSION = false;

/** Information about the JRE for Windows */
var JRE_WINDOWS_NAME = "Java Runtime 1.4.1 for Windows";
var JRE_WINDOWS_LOC = "releases/dependencies/jre-1.4.1-win32.xpi";

/** Where to find the Linux JRE */
var JRE_LINUX_HOMEPAGE = "http://java.sun.com/j2se/1.4.2/download.html";

/** Where to find the Mac JRE */
var JRE_MAC_HOMEPAGE = "http://www.apple.com/java/";

/** Where to find the Solaris JRE */
var JRE_SOLARIS_HOMEPAGE = "http://java.sun.com/j2se/1.4.2/download.html";

/** Information about the Flash Plugin for Windows */
var FLASH_WINDOWS_NAME = "Flash Plugin 7.0 for Windows";
var FLASH_WINDOWS_LOC = "releases/dependencies/flash-win32-7.0.14.xpi";

/** Where to find the Linux Flash Plugin */
var FLASH_LINUX_HOMEPAGE = "http://www.macromedia.com/shockwave/download/alternates/";

/** Where to find the Mac Flash Plugin */
var FLASH_MAC_HOMEPAGE = "http://www.macromedia.com/shockwave/download/alternates/";

/** Where to find the Solaris Flash Plugin */
var FLASH_SOLARIS_HOMEPAGE = "http://www.macromedia.com/shockwave/download/alternates/";

/** Information about the JSLib library */
var JSLIB_NAME = "JSLib: the Mozilla JavaScript Library";
var JSLIB_LOC = "releases/dependencies/jslib.xpi";


/****** Scripts */

/** Checks to make sure that this user has the correct environment to run this application, installs
	the correct version of Java and Flash, and installs the application itself. */
function installApplication() {
	if (!window.confirm("Would you like to install " + APP_IDENTIFIER + "?")) {
		return;
	}

	// first make sure that this user is using Mozilla or Firebird
	if (checkMozillaRuntime() == false) {
		return;
	}

	// Determine the XPI files that need to be installed
	var downloadXPIs = new Object();

	// add JSLib
	downloadXPIs[JSLIB_NAME] = JSLIB_LOC;

	// add the Java runtime if needed
	if (!isCorrectVersionOfJavaInstalled()) {
		if (isWindows()) {
			downloadXPIs[JRE_WINDOWS_NAME] = JRE_WINDOWS_LOC;
		}
		else if (isMacOSX() || isSolaris() || isLinux()) { // not supported as automatic installation yet
			alert("Your browser does not have the correct, latest version of Java needed to run " + APP_NAME + ". " +
			      "Press OK to be redirected to a web-page where you can download the latest version of Java");

			if (isMacOSX()) {
				window.open(JRE_MAC_HOMEPAGE);
			}
			else if (isSolaris()) {
				window.open(JRE_SOLARIS_HOMEPAGE);
			}
			else {
				window.open(JRE_LINUX_HOMEPAGE);
			}

			return;
		}
		else {
			alert("Your browser does not have the correct, latest version of Java needed to run " + APP_NAME + ". " +
			      "You must have at least version " + JAVA_VERSION + " of the Java Runtime.  Please install this version " +
			      "and retry installing " + APP_NAME);
			return;
		}
	}

	// add the Flash runtime if needed
	if (!isCorrectVersionOfFlashInstalled()) {
		if (isWindows()) {
			downloadXPIs[FLASH_WINDOWS_NAME] = FLASH_WINDOWS_LOC;
		}
		else if (isMacOSX() || isSolaris() || isLinux()) { // not supported as automatic installation yet
			alert("Your browser does not have the correct, latest version of Flash needed to run " + APP_NAME + ". " +
			      "Press OK to be redirected to a web-page where you can download the latest version of Flash");

			if (isMacOSX()) {
				window.open(FLASH_MAC_HOMEPAGE);
			}
			else if (isSolaris()) {
				window.open(FLASH_SOLARIS_HOMEPAGE);
			}
			else {
				window.open(FLASH_LINUX_HOMEPAGE);
			}

			return;
		}
		else {
			alert("Your browser does not have the correct, latest version of Flash needed to run " + APP_NAME + ". " +
			      "You must have at least version " + FLASH_VERSION + " of the Flash Plugin.  Please install this version " +
			      "and retry installing " + APP_NAME);
			return;
		}
	}

	// add our application's XPI file 
	downloadXPIs[APP_IDENTIFIER] = APP_XPI;

	// do the installation
	InstallTrigger.install(downloadXPIs);
}

/** Determines if Java is installed, and if so, if it is at least the version given in JAVA_VERSION */
function isCorrectVersionOfJavaInstalled() {
	var plugins = window.navigator.plugins;

	// go through each plugin looking for the word "Java"
	for (var i = 0; i < plugins.length; i++) {
		var currentPlugin = plugins.item(i);
		var description = currentPlugin.description;
		if (description.indexOf("Java") != -1) {
			// extract the version number (anything that has numbers and dots in it)
			var version = description.match(/[0-9\.]+/);
			
			// compare it as a floating point number to the Java version we want
			if (ONLY_SUPPORTS_THIS_JAVA_VERSION == false) {
				if (version >= JAVA_VERSION) {
					return true;
				}
			}
			else {
				if (version == JAVA_VERSION) {
					return true;
				}
			}
		}
	}

	return false;
}

/** Determines if Flash is installed, and if so, if it is at least the version given in FLASH_VERSION */
function isCorrectVersionOfFlashInstalled() {
	var plugins = window.navigator.plugins;

	// go through each plugin looking for the word "Shockwave Flash"
	for (var i = 0; i < plugins.length; i++) {
		var currentPlugin = plugins.item(i);
		var description = currentPlugin.description;
		if (description.indexOf("Shockwave Flash") != -1) {
			// extract the version number (anything that has numbers and dots in it)
			var version = description.match(/[0-9\.]+/);
			
			// compare it as a floating point number to the Java version we want
			if (ONLY_SUPPORTS_THIS_FLASH_VERSION == false) {
				if (version >= FLASH_VERSION) {
					return true;
				}
			}
			else {
				if (version == FLASH_VERSION) {
					return true;
				}
			}
		}
	}

	return false;
}

function isWindows() {
	return (window.navigator.platform.toLowerCase().indexOf("win32") != -1);
}

function isLinux() {
	return (window.navigator.platform.toLowerCase().indexOf("linux") != -1);
}

function isMacOSX() {
	return (window.navigator.platform.toLowerCase().indexOf("mac") != -1);
}

function isSolaris() {
	return (window.navigator.platform.toLowerCase().indexOf("sun") != -1);
}

/** Determines if this browser supports automatic software updates, if is is mozilla or firebird,
	and if its version is supported. 
	@returns False if this browser, such as Internet Explorer, can not run Paper Airplane. */
function checkMozillaRuntime() {
	// only mozilla runtimes have the InstallTrigger object
	if (InstallTrigger) {
		return true;
	}
	else { // Internet Explorer!
		if (SUPPORTS_MOZILLA && SUPPORTS_FIREBIRD) {
			alert(APP_NAME + " only works in Mozilla and FireBird browsers. " +
			      "Press OK to be re-directed to a web page to download Mozilla or FireBird");
		}
		else if (!SUPPORTS_MOZILLA && SUPPORTS_FIREBIRD) {
			alert(APP_NAME + " only works in the FireBird browser. " +
			      "Press OK to be re-directed to a web page to download FireBird");
		}
		else if (SUPPORTS_MOZILLA && !SUPPORTS_FIREBIRD) {
			alert(APP_NAME + " only works in the Mozilla browser. " +
			      "Press OK to be re-directed to a web page to download Mozilla");
		}
		
		window.open("http://www.mozilla.org/");
		return false;
	}
}

