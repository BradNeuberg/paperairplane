/////////////////////////////////////////////////////////////////////////////
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright 1998 Microsoft Corporation.  All Rights Reserved.
//
// Author: Scott Roberts, Microsoft Developer Support - Internet Client SDK  
//
// Portions of this code were taken from the bandobj sample that comes
// with the Internet Client SDK for Internet Explorer 4
//
//
// WBExplorerBar.cpp - CWBExplorerBar implementation
/////////////////////////////////////////////////////////////////////////////

#include <crtdbg.h>
#include <comdef.h>
#include <shlwapi.h>
#include <mshtml.h>
#include <mshtmdid.h>
#include <ExDispID.h>

#include "WBExplorerBar.h"
#include "Guid.h"

// Insert your server name 
#define STARTUP_URL "res://webband.dll/mainToolbar.html"
#define SEARCH_PANE_INDICATOR "#_mysearch"

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam);

CWBExplorerBar::CWBExplorerBar()
   : _cRef(1),
     _hwndParent(NULL),
     _hWnd(NULL),
     _hwndWB(NULL),
     _dwViewMode(0),
     _dwBandID(0),
     _dwWBCookie(0), 
     _pSite(NULL),
     _pIOleIPObject(NULL),
     _pIOleObject(NULL),
     _pFrameWB(NULL),
     _pWebBrowserOC(NULL)
{
   InterlockedIncrement(&g_cDllRefCount);
}

CWBExplorerBar::~CWBExplorerBar()
{
   Cleanup();
}

///////////////////////////////////////////////////////////////////////////
//
// IUnknown Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::QueryInterface()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::QueryInterface(REFIID riid, LPVOID* ppvObject)
{
   *ppvObject= NULL;

   if (IsEqualIID(riid, IID_IUnknown))
   {
      *ppvObject = this;
   }
   else if (IsEqualIID(riid, IID_IOleWindow) || IsEqualIID(riid, IID_IDockingWindow))
   {
      *ppvObject = static_cast<IDockingWindow*>(this);
   }
   else if (IsEqualIID(riid, IID_IInputObject))
   {
      *ppvObject = static_cast<IInputObject*>(this);
   }   
   else if (IsEqualIID(riid, IID_IObjectWithSite))
   {
      *ppvObject = static_cast<IObjectWithSite*>(this);
   }   
   else if (IsEqualIID(riid, IID_IDeskBand))
   {
      *ppvObject = static_cast<IDeskBand*>(this);
   }   
   else if (IsEqualIID(riid, IID_IPersist))
   {
      *ppvObject = static_cast<IPersist*>(this);
   }   
   else if (IsEqualIID(riid, IID_IPersistStream))
   {
      *ppvObject = static_cast<IPersistStream*>(this);  
   }   
   else if (IsEqualIID(riid, IID_IContextMenu))
   {
      *ppvObject = static_cast<IContextMenu*>(this);
   }   
   else if (IsEqualIID(riid, IID_IOleClientSite))
   {
      *ppvObject = static_cast<IOleClientSite*>(this);
   }   
   else if (IsEqualIID(riid, IID_IOleInPlaceSite))
   {
      *ppvObject = static_cast<IOleInPlaceSite*>(this);
   }   
   else if (IsEqualIID(riid, IID_IOleControlSite))
   {
      *ppvObject = static_cast<IOleControlSite*>(this);
   }   
   else if (IsEqualIID(riid, IID_IDispatch) || IsEqualIID(riid, DIID_DWebBrowserEvents2))
   {
      *ppvObject = static_cast<IDispatch*>(this);
   }   

   if (*ppvObject)
   {
      static_cast<LPUNKNOWN>(*ppvObject)->AddRef();
      return S_OK;
   }

   return E_NOINTERFACE;
}                                             

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::AddRef()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP_(ULONG) CWBExplorerBar::AddRef()
{
   return (ULONG)InterlockedIncrement(&_cRef);
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::Release()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP_(ULONG) CWBExplorerBar::Release()
{
   if (0 == InterlockedDecrement(&_cRef))
   {
      delete this;
      return 0;
   }
   
   return (ULONG)_cRef;
}

///////////////////////////////////////////////////////////////////////////
//
// IOleWindow Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetWindow()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetWindow(HWND *phwnd)
{
   *phwnd = _hWnd;
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::ContextSensitiveHelp()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::ContextSensitiveHelp(BOOL fEnterMode)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
// IDockingWindow Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::ShowDW()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::ShowDW(BOOL fShow)
{
   if (_hWnd)
   {
      //
      // Hide or show the window depending on
      // the value of the fShow parameter.
      //
      if (fShow)
         ShowWindow(_hWnd, SW_SHOW);
      else
         ShowWindow(_hWnd, SW_HIDE);
   }

   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::CloseDW()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::CloseDW(DWORD dwReserved)
{
   ShowDW(FALSE);

   if (IsWindow(_hWnd))
      DestroyWindow(_hWnd);

   _hWnd = NULL;
   
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::ResizeBorderDW()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::ResizeBorderDW(LPCRECT prcBorder, IUnknown* punkToolbarSite,
                                            BOOL fReserved)
{
   // This method is never called for Band Objects.
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
// IInputObject Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::UIActivateIO()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::UIActivateIO(BOOL fActivate, LPMSG lpMsg)
{
   _ASSERT(_pIOleObject);

   HRESULT hr = E_FAIL;

   if (_pIOleObject)
   {
      RECT  rc;
      GetClientRect(_hwndParent, &rc);

      //
      // If we are being activated, we must UI Activate the WebBrowser
      // control in order for all accelerators to work.
      //
      if (fActivate)
         hr = _pIOleObject->DoVerb(OLEIVERB_UIACTIVATE, lpMsg, this, 0, _hwndParent, &rc);
      else
         hr = _pIOleObject->DoVerb(OLEIVERB_INPLACEACTIVATE, lpMsg, this, 0, _hwndParent, &rc);
    }

   return hr;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::HasFocusIO()
//   
//   If this window or one of its decendants has the focus, return S_OK. Return 
//   S_FALSE if we don't have the focus.
//
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::HasFocusIO(void)
{
   HWND hwnd = GetFocus();
   HWND hwndTmp = _hwndWB;

   // See if the focus has been set to any of the children
   //
   while (hwnd && hwndTmp)
   {
      if (hwnd == hwndTmp)
         return S_OK;

      hwndTmp = ::GetWindow(hwndTmp, GW_CHILD);
   }

   return S_FALSE;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::TranslateAcceleratorIO()
//   
//   If the accelerator is translated, return S_OK or S_FALSE otherwise.
//
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::TranslateAcceleratorIO(LPMSG pMsg)
{
   _RPT0(_CRT_WARN, "TranslateAcceleratorIO\n");

   LPDISPATCH pDisp = NULL;
   HRESULT hr = S_FALSE;
   IOleInPlaceActiveObject* pIPO;

   //
   // Send accelerator messages to the WebBrowser control
   // so that keys such as backspace and delete will work correctly.
   //
   hr = _pWebBrowserOC->get_Application(&pDisp);
   if (SUCCEEDED(hr))
   {
      hr = pDisp->QueryInterface(IID_IOleInPlaceActiveObject, (LPVOID*)&pIPO);
      pDisp->Release();

      if (SUCCEEDED(hr))
      {
         hr = pIPO->TranslateAccelerator(pMsg);
         pIPO->Release();
      }
   }

   return hr;
}

///////////////////////////////////////////////////////////////////////////
//
// IObjectWithSite Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::SetSite()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::SetSite(IUnknown* pUnkSite)
{
   // If punkSite is not NULL, a new site is being set.
   if (pUnkSite)
   {
      //
      // If a IInputObjectSite pointer is being held, release it.
      //
      if (_pSite)
      {
         _pSite->Release();
         _pSite = NULL;
      }

      // Get the parent window.
      IOleWindow* pOleWindow;
   
      if (SUCCEEDED(pUnkSite->QueryInterface(IID_IOleWindow,
											            (LPVOID*)&pOleWindow)))
      {
         pOleWindow->GetWindow(&_hwndParent);
         pOleWindow->Release();
      }

      _ASSERT(_hwndParent);
      if (!_hwndParent)
         return E_FAIL;

      if (!RegisterAndCreateWindow())
         return E_FAIL;

      // Get and keep the IInputObjectSite pointer.
      HRESULT hr = pUnkSite->QueryInterface(IID_IInputObjectSite,
											           (LPVOID*)&_pSite);
      _ASSERT(SUCCEEDED(hr));

      //
      // Get the IWebBrowser2 interface of Internet Explorer
      // This is so we can do such things as navigate in the main
      // window and write to the status bar.
      //
      IOleCommandTarget* pCmdTarget;
      hr = pUnkSite->QueryInterface(IID_IOleCommandTarget,
                                    (LPVOID*)&pCmdTarget);
      if (SUCCEEDED(hr))
      {
         IServiceProvider* pSP;
         hr = pCmdTarget->QueryInterface(IID_IServiceProvider,
                                         (LPVOID*)&pSP);

         pCmdTarget->Release();

         if (SUCCEEDED(hr))
         {
            if (_pFrameWB)
            {
               _pFrameWB->Release();
               _pFrameWB = NULL;
            }

            hr = pSP->QueryService(SID_SWebBrowserApp,
                                   IID_IWebBrowser2,
                                   (LPVOID*)&_pFrameWB);
            _ASSERT(_pFrameWB);

            pSP->Release();
         }
      }

      // Create and initialize the WebBrowser control that we are hosting.
      hr = CoCreateInstance(CLSID_WebBrowser, NULL, CLSCTX_INPROC,
                            IID_IOleObject, (LPVOID*)&_pIOleObject);
      if (hr != S_OK)
         return E_FAIL;

      if (_pIOleObject->SetClientSite(this) != S_OK)
         return E_FAIL;

      // Get the rectangle of the client area
      RECT rcClient = { CW_USEDEFAULT, 0, 0, 0 };
      GetClientRect(_hWnd, &rcClient);

      MSG msg;

      // In-place activate the WebBrowser control
      hr = _pIOleObject->DoVerb(OLEIVERB_INPLACEACTIVATE, &msg,
                                this, 0, _hWnd, &rcClient);
      _ASSERT(SUCCEEDED(hr));

      if (FAILED(hr))
         return E_FAIL;

      //
      // Get the pointer to the WebBrowser control. 
      //
      hr = _pIOleObject->QueryInterface(IID_IWebBrowser2,
                                        (LPVOID*)&_pWebBrowserOC);
      _ASSERT(_pWebBrowserOC);

      if (FAILED(hr))
         return E_FAIL;
      else
      {
         // Set up an event sink for the WebBrowser events
         if (_pWebBrowserOC)
            AdviseWBEventSink();

         //
         // QI for the in-place object to set the size.
         //
         if (_pIOleIPObject)
         {
            _pIOleIPObject->Release();
            _pIOleIPObject = NULL;
         }

         hr = _pWebBrowserOC->QueryInterface(IID_IOleInPlaceObject,
                                             (LPVOID*)&_pIOleIPObject);
         _ASSERT(_pIOleIPObject);

         if (FAILED(hr))
            return E_FAIL;

         hr = _pIOleIPObject->SetObjectRects(&rcClient, &rcClient);
         _ASSERT(SUCCEEDED(hr));

         // Navigate to the sample search page
         _variant_t vtEmpty;
         _bstr_t bstrURL(STARTUP_URL);

         _pWebBrowserOC->Navigate(bstrURL, &vtEmpty, &vtEmpty,
                                  &vtEmpty, &vtEmpty);

         // Get the HWND of the WebBrowser OC
         //
         IOleWindow* pWnd;

         if (SUCCEEDED(_pWebBrowserOC->QueryInterface(IID_IOleWindow,
                                                      (LPVOID*)&pWnd)))
         {
            pWnd->GetWindow(&_hwndWB);
         }
      }
   }

   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetSite()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetSite(REFIID riid, void** ppvSite)
{
   *ppvSite = NULL;

   if (_pSite)
      return _pSite->QueryInterface(riid, ppvSite);

   return E_FAIL;
}

///////////////////////////////////////////////////////////////////////////
//
// IDeskBand implementation
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetBandInfo()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetBandInfo(DWORD dwBandID,
										 DWORD dwViewMode,
										 DESKBANDINFO* pdbi)
{
   if (pdbi)
   {
      _dwBandID = dwBandID;
      _dwViewMode = dwViewMode;

      if (pdbi->dwMask & DBIM_MINSIZE)
      {
         pdbi->ptMinSize.x = MIN_SIZE_X;
         pdbi->ptMinSize.y = MIN_SIZE_Y;
      }

      if (pdbi->dwMask & DBIM_MAXSIZE)
      {
         pdbi->ptMaxSize.x = -1;
         pdbi->ptMaxSize.y = -1;
      }

      if (pdbi->dwMask & DBIM_INTEGRAL)
      {
         pdbi->ptIntegral.x = 1;
         pdbi->ptIntegral.y = 1;
      }

      if (pdbi->dwMask & DBIM_ACTUAL)
      {
         pdbi->ptActual.x = ACTUAL_SIZE_X;
         pdbi->ptActual.y = ACTUAL_SIZE_Y;
      }

      if (pdbi->dwMask & DBIM_TITLE)
      { 
         lstrcpyW(pdbi->wszTitle, L"WebBand Search");
      }

      if (pdbi->dwMask & DBIM_MODEFLAGS)
         //pdbi->dwModeFlags = DBIMF_VARIABLEHEIGHT;
   
      if (pdbi->dwMask & DBIM_BKCOLOR)
      {
         // Use the default background color by removing this flag.
         pdbi->dwMask &= ~DBIM_BKCOLOR;
      }

      return S_OK;
   }

   return E_INVALIDARG;
}

///////////////////////////////////////////////////////////////////////////
//
// IPersistStream Methods
// 
// This is only supported to allow the desk band to be dropped on the 
// desktop and to prevent multiple instances of the desk band from showing 
// up in the context menu. This desk band doesn't actually persist any data.
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetClassID()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetClassID(LPCLSID pClassID)
{
   *pClassID = CLSID_WBExplorerBar;
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::IsDirty()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::IsDirty(void)
{
   return S_FALSE;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::Load()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::Load(LPSTREAM pStream)
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::Save()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::Save(LPSTREAM pStream, BOOL fClearDirty)
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetSizeMax()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetSizeMax(ULARGE_INTEGER *pul)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
// IContextMenu Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::QueryContextMenu()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::QueryContextMenu(HMENU hmenu,
                                              UINT indexMenu, 
                                              UINT idCmdFirst,
                                              UINT idCmdLast, 
                                              UINT uFlags)
{
   if (!(CMF_DEFAULTONLY & uFlags))
   {
      InsertMenu(hmenu, indexMenu, MF_STRING | MF_BYPOSITION,
                 idCmdFirst + IDM_REFRESH, "&Refresh");

      InsertMenu(hmenu, indexMenu + 1, MF_STRING | MF_BYPOSITION,
                 idCmdFirst + IDM_OPENINWINDOW, "&Open in Window");

      return MAKE_HRESULT(SEVERITY_SUCCESS, 0,
                          USHORT(IDM_OPENINWINDOW + 1));
   }

   return MAKE_HRESULT(SEVERITY_SUCCESS, 0, USHORT(0));
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::InvokeCommand()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::InvokeCommand(LPCMINVOKECOMMANDINFO lpici)
{
   switch (LOWORD(lpici->lpVerb))
   {
      case IDM_REFRESH:
         _pWebBrowserOC->Refresh();
         break;

      case IDM_OPENINWINDOW:
         {
            BSTR bstrURL;

            HRESULT hr = _pWebBrowserOC->get_LocationURL(&bstrURL);
            if (SUCCEEDED(hr))
            {
               _variant_t vtEmpty;
               _variant_t vtFlags((long)(navOpenInNewWindow|navNoHistory));

               hr = _pWebBrowserOC->Navigate(bstrURL, &vtFlags, 
                                             &vtEmpty, &vtEmpty, &vtEmpty);
            }

            break;
         }

      default:
         return E_INVALIDARG;
   }

   return NOERROR;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetCommandString()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetCommandString(UINT idCmd, UINT uType, UINT* pwReserved,
                                              LPSTR pszName, UINT cchMax)
{
   HRESULT hr = E_INVALIDARG;

   switch(uType)
   {
      case GCS_HELPTEXT:
         switch(idCmd)
         {
            case IDM_REFRESH:
               lstrcpy(pszName, TEXT("Refreshes the search window"));
               hr = NOERROR;
               break;

            case IDM_OPENINWINDOW:
               lstrcpy(pszName, TEXT("Open a new instance of the Internet Explorer window"));
               hr = NOERROR;
               break;
         }

         break;
   
      case GCS_VERB:
         switch(idCmd)
         {
            case IDM_REFRESH:
               lstrcpy(pszName, TEXT("Refresh"));
               hr = NOERROR;
               break;

            case IDM_OPENINWINDOW:
               lstrcpy(pszName, TEXT("Open in Window"));
               hr = NOERROR;
               break;
         }

         break;
   
      case GCS_VALIDATE:
         hr = NOERROR;
         break;
   }

   return hr;
}

///////////////////////////////////////////////////////////////////////////
//
// IOleClientSite Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::SaveObject()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::SaveObject()
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetMoniker()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetMoniker(DWORD dwAssign, DWORD dwWhichMoniker, LPMONIKER* ppmk)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetContainer()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetContainer(LPOLECONTAINER* ppContainer)
{
    *ppContainer = NULL;       
    return E_NOINTERFACE;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::ShowObject()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::ShowObject()
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnShowWindow()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnShowWindow(BOOL fShow)
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::RequestNewObjectLayout()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::RequestNewObjectLayout()
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
// IOleInPlaceSite Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::CanInPlaceActivate()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::CanInPlaceActivate(void)
{
    return S_OK;   
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnInPlaceActivate()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnInPlaceActivate(void)
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnUIActivate()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnUIActivate(void)
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetWindowContext()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetWindowContext(IOleInPlaceFrame** ppFrame, IOleInPlaceUIWindow** ppIIPUIWin, 
                                              LPRECT lprcPosRect, LPRECT lprcClipRect,
                                              LPOLEINPLACEFRAMEINFO lpFrameInfo)
{
   *ppFrame = NULL;
   *ppIIPUIWin = NULL;

   GetClientRect(_hWnd, lprcPosRect);
   GetClientRect(_hWnd, lprcClipRect);

   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::Scroll()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::Scroll(SIZE scrollExtent)
{
    return E_NOTIMPL;   
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnUIDeactivate()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnUIDeactivate(BOOL fUndoable)
{
    
    return E_NOTIMPL;   
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnInPlaceDeactivate()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnInPlaceDeactivate(void)
{
    if (_pIOleIPObject)
    {
        _pIOleIPObject->Release();
        _pIOleIPObject = NULL;
    }
    
    return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::DiscardUndoState()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::DiscardUndoState(void)
{
    return E_NOTIMPL;   
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::DeactivateAndUndo()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::DeactivateAndUndo(void)
{
    return E_NOTIMPL;   
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnPosRectChange()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnPosRectChange(LPCRECT lprcPosRect) 
{
   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
// IOleControlSite Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnControlInfoChanged()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnControlInfoChanged(void)
{
   return E_NOTIMPL;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::LockInPlaceActive()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::LockInPlaceActive(BOOL fLock)
{
   return E_NOTIMPL;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetExtendedControl()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetExtendedControl(LPDISPATCH* ppDisp)
{
   return E_NOTIMPL;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::TransformCoords()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::TransformCoords(POINTL* pPtlHimetric, POINTF* pPtfContainer, DWORD dwFlags)
{
   return E_NOTIMPL;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::TranslateAccelerator()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::TranslateAccelerator(LPMSG lpMsg, DWORD grfModifiers)
{
   return E_NOTIMPL;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnFocus()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::OnFocus(BOOL fGotFocus)
{
   _RPT1(_CRT_WARN, "OnFocus: %s\n", fGotFocus ? "True" : "False");

   if (_pSite)
      _pSite->OnFocusChangeIS(static_cast<IInputObject*>(this), fGotFocus);

   return S_OK;
}
     
///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::ShowPropertyFrame()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::ShowPropertyFrame(void)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
// Private Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetTypeInfoCount()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetTypeInfoCount(UINT* pctinfo)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetTypeInfo()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo** ppTInfo)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::GetIDsOfNames()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::GetIDsOfNames(REFIID riid, LPOLESTR* rgszNames, UINT cNames,
                                           LCID lcid,DISPID* rgDispId)
{
   return E_NOTIMPL;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::Invoke()
//   
///////////////////////////////////////////////////////////////////////////

STDMETHODIMP CWBExplorerBar::Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags,
                                    DISPPARAMS* pDispParams, VARIANT* pVarResult,
                                    EXCEPINFO* pExcepInfo, UINT* puArgErr)
{
   if (IID_NULL != riid)
      return DISP_E_UNKNOWNINTERFACE;

   if (!pDispParams)
      return DISP_E_PARAMNOTOPTIONAL;

   static bool sbIsAnchor = false;

   switch (dispIdMember)
   {
      //
      // The parameters for this DISPID:
      // [0]: New status bar text - VT_BSTR
      //
      case DISPID_STATUSTEXTCHANGE:
         if (pDispParams->cArgs && pDispParams->rgvarg[0].vt != VT_BSTR)
         {
            *puArgErr = 0;
            return DISP_E_TYPEMISMATCH;
         }

         if (_pFrameWB)
            _pFrameWB->put_StatusText(pDispParams->rgvarg[0].bstrVal);
         break;

      //
      // The parameters for this DISPID are as follows:
      // [0]: Cancel flag  - VT_BYREF|VT_BOOL
      // [1]: HTTP headers - VT_BYREF|VT_VARIANT
      // [2]: Address of HTTP POST data  - VT_BYREF|VT_VARIANT 
      // [3]: Target frame name - VT_BYREF|VT_VARIANT 
      // [4]: Option flags - VT_BYREF|VT_VARIANT
      // [5]: URL to navigate to - VT_BYREF|VT_VARIANT
      // [6]: An object that evaluates to the top-level or frame
      //      WebBrowser object corresponding to the event. 
      //
      // Note: In order to cause navigation to occur in the correct 
      //       window, I am doing a couple of things.  First, I sink
      //       events for all anchors on the page.  If an anchor
      //       is clicked, I navigate in the main window.  This works
      //       for pages that we have no control over.  For those
      //       pages over which you have control, you can use some
      //       sort of indicator in the URL to determine where you
      //       want the navigation to occur.  I am using a fragment
      //       identifier (otherwise known as a bookmark).  You cannot
      //       use the TARGET attribute.  Using TARGET cause Internet
      //       Explorer to open the link in a new window.
      //
      case DISPID_BEFORENAVIGATE2:
         {
            _bstr_t bstrURL(*pDispParams->rgvarg[5].pvarVal);

            if (!sbIsAnchor)
                ManageAnchorsEventSink(Unadvise);
            else if (pDispParams->cArgs >= 5 && !strstr(bstrURL, SEARCH_PANE_INDICATOR))
            {
               _pFrameWB->Navigate2(pDispParams->rgvarg[5].pvarVal,
                                    pDispParams->rgvarg[4].pvarVal,
                                    pDispParams->rgvarg[3].pvarVal,
                                    pDispParams->rgvarg[2].pvarVal,
                                    pDispParams->rgvarg[1].pvarVal);

               *(pDispParams->rgvarg[0].pboolVal) = VARIANT_TRUE;

               sbIsAnchor = false;
            }
         }
         break;

      case DISPID_NAVIGATECOMPLETE2:
            ManageAnchorsEventSink(Advise);
            break;

      case DISPID_HTMLELEMENTEVENTS_ONCLICK:
         sbIsAnchor = true;
         break;

      default:
         return DISP_E_MEMBERNOTFOUND;
   }

   return S_OK;
}

///////////////////////////////////////////////////////////////////////////
//
// Private Methods
//

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::WndProc()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMessage, 
                             WPARAM wParam, LPARAM lParam)
{
	if (uMessage == WM_NCCREATE)
	{
		LPCREATESTRUCT lpcs = (LPCREATESTRUCT)lParam;
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)lpcs->lpCreateParams);
	}

	CWBExplorerBar* pThis = reinterpret_cast<CWBExplorerBar*>(
                                  GetWindowLong(hWnd, GWL_USERDATA));
	if (pThis)
		return pThis->WndProc(hWnd, uMessage, wParam, lParam);
	else
		return DefWindowProc(hWnd, uMessage, wParam, lParam);
}

LRESULT CWBExplorerBar::WndProc(HWND hWnd, UINT uMessage, 
                                WPARAM wParam, LPARAM lParam)
{
   switch (uMessage)
   {
      case WM_NCCREATE:
      {
         // Set the window handle
         _hWnd = hWnd;
      }
      break;
   
      case WM_PAINT:
         return OnPaint();
   
      case WM_COMMAND:
         return OnCommand(wParam, lParam);
   
      case WM_SETFOCUS:
         return OnSetFocus();

      case WM_KILLFOCUS:
         return OnKillFocus();

      case WM_SIZE:
         return OnSize();

      case WM_DESTROY:
         //
         // If you decided to implement the Open in Window context
         // menu item and you are using Internet Explorer 5,
         // be careful.  WM_DESTROY will get sent to the band for
         // each window.  You'll want to keep a count of the number
         // of windows open and only call Cleanup() if WM_DESTROY
         // is meant for the first window.
         //
         Cleanup();

         return 0;
   }
   return DefWindowProc(hWnd, uMessage, wParam, lParam);
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnPaint()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CWBExplorerBar::OnPaint(void)
{
   PAINTSTRUCT ps;

   BeginPaint(_hWnd, &ps);
   EndPaint(_hWnd, &ps);

   return 0;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnCommand()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CWBExplorerBar::OnCommand(WPARAM wParam, LPARAM lParam)
{
   _RPT0(_CRT_WARN, "CWBExplorerBar::OnCommand\n");
   return 0;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::FocusChange()
//   
///////////////////////////////////////////////////////////////////////////

void CWBExplorerBar::FocusChange(BOOL fFocus)
{
   _RPT1(_CRT_WARN, "FocusChange: %s\n", fFocus ? "True" : "False");

   // Inform the input object site that the focus has changed
   //
   if (_pSite)
      _pSite->OnFocusChangeIS(static_cast<IDockingWindow*>(this), fFocus);
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::SetFocus()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CWBExplorerBar::OnSetFocus(void)
{
   _RPT0(_CRT_WARN, "OnSetFocus\n");

   FocusChange(TRUE);
   return 0;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnKillFocus()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CWBExplorerBar::OnKillFocus(void)
{
   _RPT0(_CRT_WARN, "OnKillFocus\n");

   FocusChange(FALSE);
   return 0;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::OnSize()
//   
///////////////////////////////////////////////////////////////////////////

LRESULT CWBExplorerBar::OnSize(void)
{
   HRESULT hr = E_FAIL;

   if (_pIOleIPObject)
   {
      RECT rcClient;
      GetClientRect(_hWnd, &rcClient);

      hr = _pIOleIPObject->SetObjectRects(&rcClient, &rcClient);
      _ASSERT(SUCCEEDED(hr));
   }

   return hr;
}

///////////////////////////////////////////////////////////////////////////
//
//   CWBExplorerBar::RegisterAndCreateWindow()
//   
///////////////////////////////////////////////////////////////////////////

BOOL CWBExplorerBar::RegisterAndCreateWindow(void)
{
   // If the window doesn't exist yet, create it now.
   if (!_hWnd)
   {
      // Can't create a child window without a parent.
      if (!_hwndParent)
         return FALSE;

      // If the window class has not been registered, then do so.
      WNDCLASS wc;
      if (!GetClassInfo(g_hInst, EB_CLASS_NAME, &wc))
      {
         ZeroMemory(&wc, sizeof(wc));
         wc.style          = CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
         wc.lpfnWndProc    = (WNDPROC)MainWndProc;
         wc.cbClsExtra     = 0;
         wc.cbWndExtra     = 0;
         wc.hInstance      = g_hInst;
         wc.hIcon          = NULL;
         wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
         wc.hbrBackground  = NULL;
         wc.lpszMenuName   = NULL;
         wc.lpszClassName  = EB_CLASS_NAME;
      
         if (!RegisterClass(&wc))
         {
            // If RegisterClass fails, CreateWindow below will fail.
         }
      }

      RECT rc;
      GetClientRect(_hWnd, &rc);

      // Create the window. The WndProc will set _hWnd.
      CreateWindowEx(0,
                     EB_CLASS_NAME,
                     NULL,
                     WS_CHILD | WS_CLIPSIBLINGS | WS_BORDER,
                     rc.left,
                     rc.top,
                     rc.right - rc.left,
                     rc.bottom - rc.top,
                     _hwndParent,
                     NULL,
                     g_hInst,
                     (LPVOID)this);
   }

   return (NULL != _hWnd);
}


///////////////////////////////////////////////////////////////////////////
//
// CWBExplorerBar::AdviseWBEventSink()
//
///////////////////////////////////////////////////////////////////////////

void CWBExplorerBar::AdviseWBEventSink(void)
{
   _ASSERT(_pWebBrowserOC);

   if (_pWebBrowserOC)
   {
      LPCONNECTIONPOINT pCP = NULL;

      // Sink WebBrowser Events
      if (SUCCEEDED(GetConnectionPoint(_pWebBrowserOC, DIID_DWebBrowserEvents2, &pCP)))
      {
         pCP->Advise(static_cast<IDispatch*>(this), &_dwWBCookie);
         pCP->Release();
      }
   }
}

///////////////////////////////////////////////////////////////////////////
//
// CWBExplorerBar::UnadviseWBEventSink()
//
///////////////////////////////////////////////////////////////////////////

void CWBExplorerBar::UnadviseWBEventSink(void)
{
   _ASSERT(_pWebBrowserOC);

   if (_pWebBrowserOC)
   {
      LPCONNECTIONPOINT pCP = NULL;

      // Unadvise the WebBrowser Event Sink 
      if (_dwWBCookie && SUCCEEDED(GetConnectionPoint(_pWebBrowserOC, DIID_DWebBrowserEvents2, &pCP)))
      {
         pCP->Unadvise(_dwWBCookie);
         pCP->Release();

         --_dwWBCookie;
      }
   }
}

/////////////////////////////////////////////////////////////////////////////
//
// CWBExplorerBar::AdviseAnchorsEventSink()
//
// Description: We must sink events for all anchors on the page.  This is
//              needed due to the fact that when a link is clicked it
//              automatically navigates in the band window.  We can't 
//              change the navigation in the BeforeNavigate2 event handler
//              because there are some things we want to navigate in the
//              current window, such as the search results.  Certain
//              anchors contain a target frame name that the Internet
//              Explorer Search Band uses to determine where the 
//              navigation should occur.  However, we don't get this 
//              target frame name.  Internet Explorer doesn't pass it to us.
//
/////////////////////////////////////////////////////////////////////////////

void CWBExplorerBar::ManageAnchorsEventSink(AdviseType adviseType)
{
   _ASSERT(_pWebBrowserOC);

   if (adviseType == Unadvise && _stackAnchorCookies.empty())
      return;

   if (_pWebBrowserOC)
   {
      // Sink Anchor Events
      IDispatch* pDisp;
      if (SUCCEEDED(_pWebBrowserOC->get_Document(&pDisp)) && pDisp)
      {
         IHTMLDocument2* pDoc;
         HRESULT hr = pDisp->QueryInterface(IID_IHTMLDocument2, (LPVOID*)&pDoc);
         pDisp->Release();

         if (FAILED(hr))
            return;

         //
         // Advise all the anchors on the page so we can get the onclick events
         // For the search pages, the anchors collection is empty.  Therefore,
         // we have to iterate through the entire all collection and advise
         // each anchor tag.
         //
         IHTMLElementCollection* pElemColl;
         hr = pDoc->get_all(&pElemColl);
         pDoc->Release();

         if (FAILED(hr))
            return;

         long lNumElems = 0;
         pElemColl->get_length(&lNumElems);

         for (int i = 0; i < lNumElems; i++)
         {
            _variant_t vtItem((long)i), vtEmpty;
            hr = pElemColl->item(vtItem, vtEmpty, &pDisp);

            if (FAILED(hr))
               break;

            // Get the IHTMLElement interface
            IHTMLElement* pElem;

            hr = pDisp->QueryInterface(IID_IHTMLElement, (LPVOID*)&pElem);
            pDisp->Release();

            if (FAILED(hr))
               break;

            BSTR bstr;
            hr = pElem->get_tagName(&bstr);

            if (SUCCEEDED(hr))
            {
               _bstr_t bstrTagName(bstr);

               if (!lstrcmpi(bstrTagName, "A"))
               {
                  LPCONNECTIONPOINT pCP = NULL;

                  if (SUCCEEDED(GetConnectionPoint(pElem, DIID_HTMLAnchorEvents, &pCP)))
                  {
                     if (adviseType == Advise)
                     {  
                        DWORD dwCookie;
   
                        // Connect the event sink
                        hr = pCP->Advise(static_cast<IDispatch*>(this), &dwCookie);

                        if (SUCCEEDED(hr))
                           _stackAnchorCookies.push(dwCookie);

                        pCP->Release();
                     }
                     else if (!_stackAnchorCookies.empty())
                     {
                        // Disconnect the event sink
                        hr = pCP->Unadvise(_stackAnchorCookies.top());
                        pCP->Release();

                        _stackAnchorCookies.pop();
                     }
                  }
               }
            }

            pElem->Release();
         }

         pElemColl->Release();
      }
   }
}

///////////////////////////////////////////////////////////////////////////
//
// CWBExplorerBar::GetConnectionPoint()
//
///////////////////////////////////////////////////////////////////////////

HRESULT CWBExplorerBar::GetConnectionPoint(LPUNKNOWN pUnk, REFIID riid, LPCONNECTIONPOINT* ppCP)
{
   _ASSERT(_pWebBrowserOC);

   HRESULT hr = E_FAIL;
   IConnectionPointContainer* pCPC;

   if (_pWebBrowserOC)
   {
      hr = pUnk->QueryInterface(IID_IConnectionPointContainer, (LPVOID*)&pCPC);
      if (FAILED(hr))
         return hr;

      hr = pCPC->FindConnectionPoint(riid, ppCP);
      pCPC->Release();
   }

   return hr;
}

///////////////////////////////////////////////////////////////////////////
//
// CWBExplorerBar::Cleanup()
//
// Description: This method releases all interfaces we are holding onto.
//              This has to be done here because Internet Explorer is not
//              releasing all of our interfaces.  Therefore, our ref count
//              never reaches 0 and we never delete ourself.
//
///////////////////////////////////////////////////////////////////////////

void CWBExplorerBar::Cleanup(void)
{
   if (_pSite)
   {
      _pSite->Release();
      _pSite = NULL;
   }

   if (_pIOleIPObject)
   {
      _pIOleIPObject->Release();
      _pIOleIPObject = NULL;
   }

   if (_pWebBrowserOC)
   {
      UnadviseWBEventSink();
      ManageAnchorsEventSink(Unadvise);
      _pWebBrowserOC->Release();
      _pWebBrowserOC = NULL;
   }

   if (_pFrameWB)
   {
      _pFrameWB->Release();
      _pFrameWB = NULL;
   }

   if (_pIOleObject)
   {
      _pIOleObject->Release();
      _pIOleObject= NULL;
   }


   InterlockedDecrement(&g_cDllRefCount);
}

