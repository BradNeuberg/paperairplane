TITLE: SAMPLE: WebBand Hosts WebBrowser Control in an Explorer Band

---------------------------------------------------------------------
The information in this article applies to:

 - Microsoft Internet Explorer (Programming), versions 4.0, 4.01, 4.01sp1,
   5.0dp1, 5_beta
---------------------------------------------------------------------

SUMMARY
=======

WebBand is a Explorer band sample that demonstrates how to host the
WebBrowser control in an Explorer Band. (For more information about
Explorer bands, please see the REFERENCES section in this article.)

WebBand demonstrates how to deal with a lot of the complicated issues of
hosting the WebBrowser control in an Explorer band, such as keystroke and
navigation problems.

MORE INFORMATION
================

The following file is available for download from the Microsoft Software
Library:

 ~ WebBand.exe

Release Date: Aug-29-1998

For more information about downloading files from the Microsoft Software
Library, please see the following article in the Microsoft Knowledge Base:

   ARTICLE-ID: Q119591
   TITLE: How to Obtain Microsoft Support Files from Online Services

WebBand is a band object sample that demonstrates how to host the
WebBrowser control in an Vertical/Explorer band. This sample is very
similar to the Search band that comes with Internet Explorer 4.0 and later.
To use WebBand, follow these steps.

1. Copy the WebBand.htm and Results.htm files to a location on your web
   server that corresponds to the STARTUP_URL definition in the
   WBExplorerBar.cpp file.  STARTUP_URL is defined as
   "http://localhost/webband.htm", which assumes that the files are
   located on the default directory of a web server that is running on
   the same machine as the web browser.  You must change STARTUP_URL to
   reference a specific web server if you want this sample to work
   on other machines within your network, or if your web server is not
   located on the same machine where you are running this sample.

2. Compile the sample code using Visual C++ 5.0 or 6.0 (see the notes
   below for information about compiling with Visual C++ 5.0).

3. After compiling and registering WebBand.dll, start Internet Explorer 4.0
   or above and choose WebBand Search from the View menu. If you are using
   Internet Explorer 4.0x, this will be located under the Explorer submenu
   of the View menu.

WebBand will load WebBand.htm, which contains a form with an edit box and
Submit button and a couple of links to other Web pages. When you type in
the edit box and click the Submit button, the Results.htm file will be
loaded in the current window. If you click on one of the links on the
WebBand.htm Web page, the URL will be loaded in the main Internet Explorer
window.

If you are running Internet Explorer 5.0 or higher then a button is added
to Internet Explorer's toolbar that displays the WebBand when pressed.
Adding buttons to the toolbar is not supported in Internet Explorer 4.

WebBand is able to get around the keystroke issues that are most commonly
associated with hosting the WebBrowser control in an Explorer band. These
keystroke issues often cause problems with the backspace and delete keys
when focus is set to an edit box by clicking on it with the left mouse
button. These problems are caused by focus problems. The problem is usually
that Internet Explorer does not know that the band currently has the focus.

In order to alleviate these problems, WebBand implements IOleControlSite.
In the IOleControlSite::OnFocus method, the WebBrowser's
IInputObjectSite::OnFocusChangesIS must be called to tell the WebBrowser
that WebBand now has the focus.

Whenever a key is pressed, three things occur:

1. WebBand's IInputObject::HasFocusIO method is called to see if WebBand
   currently has the focus.

2. The IInputObject::UIActivateIO method is called to tell WebBand
   that is being activated.

3. The IInputObject::TranslateAccelerator method is called. It is here
   that WebBand passes the keystroke to the hosted WebBrowser control.
   This causes accelerator keys such as backspace and delete to be
   processed.

Another feature of WebBand is that navigation will occur in the correct
window. This is accomplished in a number of ways. When a page is loaded,
WebBand sinks events for all anchors on the page through the "all"
collection. When an anchor is clicked, the target of the navigation is
changed from the band window to the main Internet Explorer window.

Using Internet Explorer 4.0, you are only able to navigate to WebBand.htm
and Results.htm. The Back link on the search results page, has a fragment
identifier (that is, bookmark) associated with it. This fragment identifier
is currently named "#_mysearch." In the BeforeNavigate2 event handler,
WebBand checks for this fragment identifier in the URL. If it exists in the
URL, the target of the navigation is changed to the band window.

NOTE: This sample was created using Visual C++ 6.0. It will compile in
Visual C++ 5.0 but you will see some compiler warnings due to new Visual
C++ 6.0 compiler directives.

REFERENCES
==========

Explorer Bars/Band Objects in the Site Builder Workshop:

http://www.microsoft.com/workshop/browser/ext/overview/bands.asp

Reusing the WebBrowser control:

http://www.microsoft.com/workshop/browser/webbrowser/WebBrowser.asp

BandObjs sample in the Platform SDK.

(c) Microsoft Corporation 1998, All Rights Reserved. Contributions by Scott
Roberts, Microsoft Corporation.
