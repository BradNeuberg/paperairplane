/////////////////////////////////////////////////////////////////////////////
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright 1998 Microsoft Corporation.  All Rights Reserved.
//
// Author: Scott Roberts, Microsoft Developer Support - Internet Client SDK  
//
// Portions of this code were taken from the bandobj sample that comes
// with the Internet Client SDK for Internet Explorer 4.0x
//
// WebBand.cpp : Contains DLLMain and standard COM object functions.
/////////////////////////////////////////////////////////////////////////////

#include <ole2.h>
#include <comcat.h>
#include <olectl.h>
#include "ClsFact.h"
#include "res/resource.h"

// This part is only done once
// If you need to use the GUID in another file, just include Guid.h
//#pragma data_seg(".text")
#define INITGUID
#include <initguid.h>
#include <shlguid.h>
#include "Guid.h"
//#pragma data_seg()

extern "C" BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID);
BOOL RegisterServer(CLSID, LPTSTR);
BOOL RegisterComCat(CLSID, CATID);
BOOL UnRegisterServer(CLSID);
BOOL UnRegisterComCat(CLSID, CATID);

HINSTANCE  g_hInst;
LONG       g_cDllRefCount;

typedef struct
{
   HKEY   hRootKey;
   LPTSTR szSubKey;  // TCHAR szSubKey[MAX_PATH];
   LPTSTR lpszValueName;
   LPTSTR szData;    // TCHAR szData[MAX_PATH];

} DOREGSTRUCT, *LPDOREGSTRUCT;


extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
   switch(dwReason)
   {
      case DLL_PROCESS_ATTACH:
         g_hInst = hInstance;
         break;

      case DLL_PROCESS_DETACH:
         break;
   }
   
   return TRUE;
}                                 

STDAPI DllCanUnloadNow(void)
{
   return (g_cDllRefCount ? S_FALSE : S_OK);
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
   *ppv = NULL;

   // If we don't support this classid, return the proper error code
   if (!IsEqualCLSID(rclsid, CLSID_WBExplorerBar))
      return CLASS_E_CLASSNOTAVAILABLE;
   
   // Create a CClassFactory object and check it for validity
   CClassFactory* pClassFactory = new CClassFactory(rclsid);
   if (NULL == pClassFactory)
      return E_OUTOFMEMORY;
   
   // QI for the requested interface
   HRESULT hr = pClassFactory->QueryInterface(riid, ppv);

   // Call Release to decement the ref count - creating the object set it to one 
   // and QueryInterface incremented it - since its being used externally (not by 
   // us), we only want the ref count to be 1
   pClassFactory->Release();

   return hr;
}

STDAPI DllRegisterServer(void)
{
   // Register the explorer bar object.
   if (!RegisterServer(CLSID_WBExplorerBar, TEXT("&WebBand Search")))
      return SELFREG_E_CLASS;

   // Register the Component Categories for the explorer bar object.
   //if (!RegisterComCat(CLSID_WBExplorerBar, CATID_CommBand))
   //   return SELFREG_E_CLASS;

   //return S_OK;

	// registers object, typelib and all interfaces in typelib
	HKEY hKeyLocal = NULL;
	RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Internet Explorer\\Toolbar"), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKeyLocal, NULL);
	RegSetValueEx(hKeyLocal, CLSID_WBExplorerBar_Registry, 0, REG_BINARY, NULL, 0);
	RegCloseKey(hKeyLocal);

	return S_OK;
}

STDAPI DllUnregisterServer(void)
{
   // Register the Component Categories for the explorer bar object.
   //if (!UnRegisterComCat(CLSID_WBExplorerBar, CATID_CommBand))
   //   return SELFREG_E_CLASS;

   // Register the explorer bar object.
   if (!UnRegisterServer(CLSID_WBExplorerBar))
      return SELFREG_E_CLASS;

   HKEY hKeyLocal = NULL;
   RegCreateKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Internet Explorer\\Toolbar"), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKeyLocal, NULL);
   RegDeleteValue(hKeyLocal, CLSID_WBExplorerBar_Registry);
   RegCloseKey(hKeyLocal);

   return S_OK;
}

BOOL RegisterServer(CLSID clsid, LPTSTR lpszTitle)
{
   int     i;
   HKEY    hKey;
   LRESULT lResult;
   DWORD   dwDisp;
   TCHAR   szSubKey[MAX_PATH];
   TCHAR   szCLSID[MAX_PATH];
   TCHAR   szWebBandCLSID[MAX_PATH];
   TCHAR   szModule[MAX_PATH];
   LPWSTR  pwsz;

   // Get the CLSID in string form
   StringFromIID(clsid, &pwsz);

   if (pwsz)
   {
#ifdef UNICODE
      lstrcpy(szWebBandCLSID, pwsz);
#else
      WideCharToMultiByte(CP_ACP, 0, pwsz, -1, szWebBandCLSID,
                          ARRAYSIZE(szWebBandCLSID), NULL, NULL);
#endif

      // Free the string
      LPMALLOC pMalloc;

      CoGetMalloc(1, &pMalloc);
      pMalloc->Free(pwsz);

      pMalloc->Release();
   }

   // Get this app's path and file name
   GetModuleFileName(g_hInst, szModule, ARRAYSIZE(szModule));

   DOREGSTRUCT ClsidEntries[] =
   {
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s"),                 
         NULL, lpszTitle,
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\InprocServer32"), 
         NULL, szModule,
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\InprocServer32"),
         TEXT("ThreadingModel"), TEXT("Apartment"),
      NULL, NULL, NULL, NULL
   };

   // Register the CLSID entries
   for (i = 0; ClsidEntries[i].hRootKey; i++)
   {
      // Create the sub key string - for this case, insert
      // the file extension
      //
      wsprintf(szSubKey, ClsidEntries[i].szSubKey, szWebBandCLSID);

      lResult = RegCreateKeyEx(ClsidEntries[i].hRootKey, szSubKey, 
                               0, NULL, REG_OPTION_NON_VOLATILE,
                               KEY_WRITE, NULL, &hKey, &dwDisp);
   
      if (ERROR_SUCCESS == lResult)
      {
         TCHAR szData[MAX_PATH];

         // If necessary, create the value string
         wsprintf(szData, ClsidEntries[i].szData, szModule);
   
         lResult = RegSetValueEx(hKey, ClsidEntries[i].lpszValueName, 
                                 0, REG_SZ, (LPBYTE)szData,
                                 lstrlen(szData) + 1);
         RegCloseKey(hKey);

         if (ERROR_SUCCESS != lResult)
            return FALSE;
      }
      else
      {
         return FALSE;
      }
   }

   // Create the Registry key entry and values for the
   // toolbar button.
   //
   StringFromIID(CLSID_WebBandButton, &pwsz);

   if (!pwsz)
      return TRUE;

#ifdef UNICODE
   lstrcpy(szCLSID, pwsz);
#else
   WideCharToMultiByte(CP_ACP, 0, pwsz, -1, szCLSID,
                       ARRAYSIZE(szCLSID), NULL, NULL);
#endif

   // Free the string
   LPMALLOC pMalloc;

   CoGetMalloc(1, &pMalloc);
   pMalloc->Free(pwsz);
   pMalloc->Release();

   wsprintf(szSubKey, "Software\\Microsoft\\Internet Explorer\\Extensions\\%s",
            szCLSID);

   lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, szSubKey, 
                            0, NULL, REG_OPTION_NON_VOLATILE,
                            KEY_WRITE, NULL, &hKey, &dwDisp);
   
   if (ERROR_SUCCESS == lResult)
   {
      TCHAR szData[MAX_PATH];

      // Create the value strings
      //
      lstrcpy(szData, "WebBand");
      RegSetValueEx(hKey, TEXT("ButtonText"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      lstrcpy(szData, "Yes");
      RegSetValueEx(hKey, TEXT("Default Visible"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      TCHAR szPath[MAX_PATH];
      HMODULE hModule;

      hModule = GetModuleHandle(TEXT("WebBand.dll"));
      GetModuleFileName(hModule, szPath, MAX_PATH);

      wsprintf(szData, "%s,%d", szPath, IDI_HOTICON);
      RegSetValueEx(hKey, TEXT("HotIcon"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      wsprintf(szData, "%s,%d", szPath, IDI_ICON);
      RegSetValueEx(hKey, TEXT("Icon"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      lstrcpy(szData, "{E0DD6CAB-2D10-11D2-8F1A-0000F87ABD16}");
      RegSetValueEx(hKey, TEXT("CLSID"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      wsprintf(szData, "%s", szWebBandCLSID);
      RegSetValueEx(hKey, TEXT("BandCLSID"), 
                    0, REG_SZ, (LPBYTE)szData,
                    lstrlen(szData) + 1);

      RegCloseKey(hKey);
   }

   return TRUE;
}

BOOL RegisterComCat(CLSID clsid, CATID CatID)
{
   ICatRegister* pcr;
   HRESULT hr = S_OK ;
    
   CoInitialize(NULL);

   hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
                         NULL,
                         CLSCTX_INPROC_SERVER, 
                         IID_ICatRegister,
                         (LPVOID*)&pcr);

   if (SUCCEEDED(hr))
   {
      hr = pcr->RegisterClassImplCategories(clsid, 1, &CatID);
      pcr->Release();
   }
        
   CoUninitialize();

   return SUCCEEDED(hr);
}

BOOL UnRegisterServer(CLSID clsid)
{
   TCHAR   szSubKey[MAX_PATH];
   TCHAR   szCLSID[MAX_PATH];
   LPWSTR  pwsz;

   // Get the CLSID in string form
   StringFromIID(clsid, &pwsz);

   if (pwsz)
   {
#ifdef UNICODE
      lstrcpy(szCLSID, pwsz);
#else
      WideCharToMultiByte(CP_ACP, 0, pwsz, -1, szCLSID,
                          ARRAYSIZE(szCLSID), NULL, NULL);
#endif

      // Free the string
      LPMALLOC pMalloc;

      CoGetMalloc(1, &pMalloc);

      pMalloc->Free(pwsz);
      pMalloc->Release();
   }

   DOREGSTRUCT ClsidEntries[] =
   {
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\InprocServer32"),
         NULL, NULL,
      //
      // Remove the "Implemented Categories" key, just in case 
      // UnRegisterClassImplCategories does not remove it
      // 
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s\\Implemented Categories"),
         NULL, NULL,
      HKEY_CLASSES_ROOT, TEXT("CLSID\\%s"), NULL, NULL,
      NULL, NULL, NULL, NULL
   };

   // Delete the CLSID entries
   for (int i = 0; ClsidEntries[i].hRootKey; i++)
   {
      wsprintf(szSubKey, ClsidEntries[i].szSubKey, szCLSID);
      RegDeleteKey(ClsidEntries[i].hRootKey, szSubKey);
   }

   // Delete the button information
   //
   StringFromIID(CLSID_WebBandButton, &pwsz);

   if (!pwsz)
      return TRUE;

#ifdef UNICODE
   lstrcpy(szCLSID, pwsz);
#else
   WideCharToMultiByte(CP_ACP, 0, pwsz, -1, szCLSID,
                       ARRAYSIZE(szCLSID), NULL, NULL);
#endif

   // Free the string
   LPMALLOC pMalloc;

   CoGetMalloc(1, &pMalloc);
   pMalloc->Free(pwsz);
   pMalloc->Release();

   wsprintf(szSubKey, "Software\\Microsoft\\Internet Explorer\\Extensions\\%s", szCLSID);
   RegDeleteKey(HKEY_LOCAL_MACHINE, szSubKey);

   return TRUE;
}

BOOL UnRegisterComCat(CLSID clsid, CATID CatID)
{
   ICatRegister* pcr;
   HRESULT hr = S_OK ;
    
   CoInitialize(NULL);

   hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
                         NULL,
                         CLSCTX_INPROC_SERVER, 
                         IID_ICatRegister,
                         (LPVOID*)&pcr);

   if (SUCCEEDED(hr))
   {
      hr = pcr->UnRegisterClassImplCategories(clsid, 1, &CatID);
      pcr->Release();
   }
        
   CoUninitialize();

   return SUCCEEDED(hr);
}
