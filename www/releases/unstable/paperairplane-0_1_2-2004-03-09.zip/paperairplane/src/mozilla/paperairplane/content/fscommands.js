

/** Funnel file specific DoFSCommands to our general DoFSCommand. */
function mainToolbar_DoFSCommand(command, parameters) {
	DoFSCommand(command, parameters);
	
}

/** Funnel file specific DoFSCommands to our general DoFSCommand. */
function signOnDialog_DoFSCommand(command, parameters) {
	DoFSCommand(command, parameters);
}

/** Our main DoFSCommand. */
function DoFSCommand(command, parameters) {
	if (command == "localproxy" && parameters.indexOf("initialize") != -1) {
		var port = parameters.match("port=([0-9]*)")[1];
		startLocalProxy(port);
	}
}

/* ============= These methods handle spawning our local Java proxy ============= */

/** Finds out the path to the Paper Airplane component directory with all of our JARs */
function getPaperAirplaneComponentsPath() {
	var profileDir = getProfileDir();
	var componentsPath = profileDir + getFilePathSeparator() + "components" + 
						 getFilePathSeparator() + "paperairplane-libs" +
						 getFilePathSeparator();

	return componentsPath;
}

/** Find out the path to the user's profile directory */
function getProfileDir() {
   // First get the directory service and query interface it to
   // nsIProperties
   var dirService = Components.classes['@mozilla.org/file/directory_service;1'].
								getService(Components.interfaces.nsIProperties);

   // Next get the "ProfD" property of type nsIFile from the directory
   // service, FYI this constant is defined in
   // mozilla/xpcom/io/nsAppDirectoryServiceDefs.h
   const NS_APP_USER_PROFILE_50_DIR = "ProfD";
   profileDir = dirService.get(NS_APP_USER_PROFILE_50_DIR, Components.interfaces.nsIFile);

   // Now that we have it we can show it's path. 
   return profileDir.path;
}

/** Gets the path to the user's .paperairplane dir. */
function getPaperAirplaneDir() {
	return getProfileDir() + getFilePathSeparator() + ".paperairplane";
}

/** Gets the location to the Java executable */
function getJavaPath() {
	// find out what version of Java is the current version on this machine
	var windowsRegistry = Components.classes['@mozilla.org/winhooks;1'].
								getService(Components.interfaces.nsIWindowsRegistry);

	var currentVersion = windowsRegistry.getRegistryEntry(
							Components.interfaces.nsIWindowsRegistry.HKLM,
							"Software\\JavaSoft\\Java Runtime Environment",
							"CurrentVersion");

	// find out the location of this JRE
	var javaHome = windowsRegistry.getRegistryEntry(
							Components.interfaces.nsIWindowsRegistry.HKLM,
							"Software\\JavaSoft\\Java Runtime Environment\\" + currentVersion,
							"JavaHome");

	var javaExecutable = javaHome + getFilePathSeparator() + "bin" + 
						 getFilePathSeparator() + "java.exe";

	return javaExecutable;
}

/** Runs the Java-based local proxy by spawning a process. */
function startLocalProxy(port) {
	include("chrome://jslib/content/io/fileUtils.js");
	var fileUtils = new FileUtils();

	var args = new Array();
	args.push("-jar");
	args.push(getPaperAirplaneJars());
	args.push(port);
	args.push(getPaperAirplaneDir());

	fileUtils.spawn(getJavaPath(), args);
}

/** Returns a list of the JAR files in the components/paperairplane-libs directory,
    separated by this platforms CLASSPATH separator (i.e. on windows it is the semicolon).
  */
function getPaperAirplaneJars() {
	include('chrome://jslib/content/io/dir.js');

	var jarDirName = getPaperAirplaneComponentsPath();

	var jarDir = new Dir(jarDirName);
	
	if (jarDir.exists() == false) {
			var errorString = jarDirName + " does not exist!"; 
			throw errorString;
	}

	var jarFiles = jarDirName + "paperairplane.jar";

	// the code below is no longer needed anymore, since we now use the 'Class-Path' property in our
	// paperairplane.jar file to specify our JAR dependencies
	/*var jarFilesList = jarDir.readDir();

	for (var i = 0; i < (jarFilesList.length-1); i++) {
		jarFiles = jarFiles + jarDirName + jarFilesList[i].leaf + getClasspathSeparator();
	}
	jarFiles += jarDirName + jarFilesList[jarFilesList.length-1].leaf;
	jarFiles += "\"";*/

	return jarFiles;
}

/** Returns the file path separator for this platform, such as what is used
  * for "/myharddrive/dir1/dir2". */
function getFilePathSeparator() {
	return "\\";
}

/** Returns the classpath separator for this platform, such as a semicolon */
function getClasspathSeparator() {
	return ";";
}

/* ============= End of methods handling spawning our local Java proxy ============= */

