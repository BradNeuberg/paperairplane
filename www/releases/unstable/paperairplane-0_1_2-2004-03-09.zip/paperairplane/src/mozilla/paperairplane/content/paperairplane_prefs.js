/** This file initializes all the preferences we need to make Paper Airplane work. */

var prefService = Components.classes["@mozilla.org/preferences;1"].getService(Components.interfaces.nsIPref);

// turn off searching for domain names on Google if they have no domain ending (called Keywords)
prefService.SetBoolPref("keyword.enabled", false);

// the location of our custom Proxy AutoConfiguration (PAC) file to force
// Mozilla to use our P2P web proxy for certain kinds of domain names
prefService.SetCharPref("network.proxy.autoconfig_url", "chrome://paperairplane/content/localproxy.pac");

// use a custom Proxy AutoConfiguration (PAC) file
prefService.SetIntPref("network.proxy.type",2);

// turn off adding www. and .com to the end of URLs
prefService.SetBoolPref("browser.fixup.alternate.enabled", false);