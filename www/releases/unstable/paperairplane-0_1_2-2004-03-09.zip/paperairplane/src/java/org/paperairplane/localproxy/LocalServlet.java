/* - ***** BEGIN LICENSE BLOCK *****
   - Version: MPL 1.1/GPL 2.0/LGPL 2.1
   -
   - The contents of this file are subject to the Mozilla Public License Version
   - 1.1 (the "License"); you may not use this file except in compliance with
   - the License. You may obtain a copy of the License at
   - http://www.mozilla.org/MPL/
   -
   - Software distributed under the License is distributed on an "AS IS" basis,
   - WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
   - for the specific language governing rights and limitations under the
   - License.
   -
   - The Original Code is from Paper Airplane (http://www.paperairplane.us)
   -
   - The Initial Developer of the Original Code is Brad Neuberg.
   - Portions created by the Initial Developer are Copyright (C) 2003
   - the Initial Developer. All Rights Reserved.
   -
   - Contributor(s):
   -
   - Alternatively, the contents of this file may be used under the terms of
   - either the GNU General Public License Version 2 or later (the "GPL"), or
   - the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
   - in which case the provisions of the GPL or the LGPL are applicable instead
   - of those above. If you wish to allow use of your version of this file only
   - under the terms of either the GPL or the LGPL, and not to allow others to
   - use your version of this file under the terms of the MPL, indicate your
   - decision by deleting the provisions above and replace them with the notice
   - and other provisions required by the LGPL or the GPL. If you do not delete
   - the provisions above, a recipient may use your version of this file under
   - the terms of any one of the MPL, the GPL or the LGPL.
   -
   - ***** END LICENSE BLOCK *****
   */

package org.paperairplane.localproxy;

import java.io.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class LocalServlet extends HttpServlet{
	/** The name for this peer that will be used to invoke it through HTTP.
	  */
	public static String SERVLET_NAME = "paperairplane";

	/** The attribute that encodes what command to do, such as:
	  * http://127.0.0.1/paperairplane?command=Blah
	  */
	public static String COMMAND_ATTRIBUTE = "command";

	/** Indicates to this servlet that we want to know if we initialized correctly. */
	public static String INITIALIZED_CORRECTLY_COMMAND = "initialized_correctly";

	/** Indicates to this servlet that we want to sign into the Paper Airplane network. */
	public static String SIGN_ON_COMMAND = "sign_on";

	/** The name of the attribute that has the username for the SIGN_ON_COMMAND and the
	  * REGISTER_NEW_USER_COMMAND. */
	public static String USERNAME_ATTRIBUTE = "username";

	/** The name of the attribute that has the password for the SIGN_ON_COMMAND and the
	  * REGISTER_NEW_USER_COMMAND. */
	public static String PASSWORD_ATTRIBUTE = "password";

	/** The name of the attribute that has the port to start the P2P to Web proxy on. */
	public static String P2P_WEB_PROXY_PORT_ATTRIBUTE = "port";

	/** Indicates to this servlet that we want to start 
	  * any P2P services we need to start on this peer, such as the P2P To Web Proxy
	  * or starting up any Paper Airplane Groups we created in previous sessions. */
	public static String START_P2P_SERVICES = "start_p2p_services";

	/** Indicates to this servlet that we want to register a new user (i.e. create a new
	  * account. */
	public static String REGISTER_NEW_USER_COMMAND = "register_user";

	/** Indicates to this servlet that we want to create a new Paper Airplane Group.
	  */
	public static String CREATE_GROUP_COMMAND = "create_group";

	/** The name of the attribute that has the group name for the CREATE_GROUP_COMMAND.
	  */
	public static String GROUP_NAME_ATTRIBUTE = "name";

	/** Indicates to this servlet that we want to sign off.
	  */
	public static String SIGN_OFF_COMMAND = "sign_off";

	/** The string key used to store in the Servlet Context the location to our
	  * .paperairplane directory. */
	public static String PAPERAIRPLANE_DIR="paperairplane_dir";

	/** Contains most of the logic for dealing with Paper Airplane. */
	private PaperAirplane paperAirplane;

	public void init() throws ServletException {
		try {
			ServletContext context = getServletConfig().getServletContext();
			String paperairplaneDir = (String)context.getAttribute(LocalServlet.PAPERAIRPLANE_DIR);
			paperAirplane = new PaperAirplane(paperairplaneDir);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}

	public void doGet (HttpServletRequest request,   HttpServletResponse response)
											throws ServletException, IOException {   
		try {
			String command = request.getParameter(COMMAND_ATTRIBUTE);
			if (command == null || command.equals("")) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
								   "You must provide the following query attribute: " + COMMAND_ATTRIBUTE);
			}
			else {
				if (command.equals(INITIALIZED_CORRECTLY_COMMAND)) {
					handleInitializedCorrectlyCommand(request, response);
				}
				else if (command.equals(SIGN_ON_COMMAND)) {
					handleSignOnCommand(request, response);
				}
				else if (command.equals(START_P2P_SERVICES)) {
					handleStartP2PServicesCommand(request, response);
				}
				else if (command.equals(REGISTER_NEW_USER_COMMAND)) {
					handleRegisterNewUserCommand(request, response);
				}
				else if (command.equals(CREATE_GROUP_COMMAND)) {
					handleCreateGroupCommand(request, response);
				}
				else if (command.equals(SIGN_OFF_COMMAND)) {
					handleSignOffCommand(request, response);
				}
				else {
					response.sendError(HttpServletResponse.SC_NOT_IMPLEMENTED,
									   "An unknown command was given: " + command);
				}
			}
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}

	protected void handleInitializedCorrectlyCommand(HttpServletRequest request, HttpServletResponse response)
																throws Exception {
		PrintWriter out = response.getWriter();

		out.print("initialized=true");
		out.close();
	}

	protected void handleSignOnCommand(HttpServletRequest request, HttpServletResponse response)
					throws Exception {
		Exception e = null;
		boolean results = false;
		PrintWriter out = response.getWriter();
		try {
			if (request.getParameter(USERNAME_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + USERNAME_ATTRIBUTE);
				return;
			}

			String username = (String)request.getParameter(USERNAME_ATTRIBUTE);

			if (request.getParameter(PASSWORD_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + PASSWORD_ATTRIBUTE);
				return;
			}

			String password = (String)request.getParameter(PASSWORD_ATTRIBUTE);

			results = paperAirplane.signOn(username, password);
		}
		catch (Exception excep) {
			e = excep;
			e.printStackTrace();
		}	

		out.print("signedon="+results);
		out.print("&exception=");
		if (e != null) {
			out.print(getExceptionMessage(e));
		}

		out.close();
	}

	protected void handleStartP2PServicesCommand(HttpServletRequest request, HttpServletResponse response) 
											throws Exception {
		PrintWriter out = response.getWriter();
		Exception e = null;
		boolean results = false;

		try {
			if (request.getParameter(P2P_WEB_PROXY_PORT_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + P2P_WEB_PROXY_PORT_ATTRIBUTE);
				return;
			}

			String portStr = (String)request.getParameter(P2P_WEB_PROXY_PORT_ATTRIBUTE);
			int p2pToWebProxyPort = new Integer(portStr).intValue();

			results = paperAirplane.startP2PServices(p2pToWebProxyPort);
		}
		catch (Exception excep) {
			e = excep;
			e.printStackTrace();
		}

		out.print("initialized="+results);
		out.print("&exception=");
		if (e != null) {
			out.print(getExceptionMessage(e));
		}

		out.close();
	}

	protected void handleRegisterNewUserCommand(HttpServletRequest request, HttpServletResponse response)
					throws Exception {
		Exception e = null;
		boolean results = false;
		PrintWriter out = response.getWriter();
		try {
			if (request.getParameter(USERNAME_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + USERNAME_ATTRIBUTE);
				return;
			}

			String username = (String)request.getParameter(USERNAME_ATTRIBUTE);

			if (request.getParameter(PASSWORD_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + PASSWORD_ATTRIBUTE);
				return;
			}

			String password = (String)request.getParameter(PASSWORD_ATTRIBUTE);

			results = paperAirplane.registerUser(username, password);
		}
		catch (Exception excep) {
			e = excep;
			e.printStackTrace();
		}	

		out.print("registeruser="+results);
		out.print("&exception=");
		if (e != null) {
			out.print(getExceptionMessage(e));
		}

		out.close();
	}

	protected void handleCreateGroupCommand(HttpServletRequest request, HttpServletResponse response)
					throws Exception {
		Exception e = null;
		boolean results = false;
		PrintWriter out = response.getWriter();
		try {
			if (request.getParameter(GROUP_NAME_ATTRIBUTE) == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, 
						   "You must provide the following query attribute: " 
						   + GROUP_NAME_ATTRIBUTE);
				return;
			}

			String groupName = (String)request.getParameter(GROUP_NAME_ATTRIBUTE);

			System.out.println("LocalServlet.handleCreateGroupCommand(): groupName="+groupName);
			results = paperAirplane.createGroup(groupName);
		}
		catch (Exception excep) {
			e = excep;
		}	

		out.print("creategroup="+results);
		out.print("&exception=");
		if (e != null) {
			out.print(getExceptionMessage(e));
		}

		out.close();
	}

	protected void handleSignOffCommand(HttpServletRequest request, HttpServletResponse response)
					throws Exception {
		Exception e = null;
		boolean results = false;
		PrintWriter out = response.getWriter();
		try {
			results = paperAirplane.signOff();
		}
		catch (Exception excep) {
			e = excep;
		}	

		out.print("signedoff="+results);
		out.print("&exception=");
		if (e != null) {
			out.print(getExceptionMessage(e));
		}

		out.close();
	}

	/** A utility method that extracts out the string portion of an exception.
	  * For example, if we have "net.jxta.ext.profiler.ConfiguratorException: Your peer could not be profiled",
	  * then this method extracts "Your peer could not be profiled".
	  */
	protected String getExceptionMessage(Throwable t) {
		StringTokenizer tk = new StringTokenizer(t.getMessage(), ":", false);
		if (tk.countTokens() < 2) {
			return t.getMessage();
		}
		else {
			tk.nextToken();
			String token = tk.nextToken();
			return token;
		}
	}
}
