//	THIS CODE IS EXPERIMENTAL.  IT WORKS, BUT DON'T RELY ON IT.
//	tltabor@earthlink.net

#ifndef _TOOLBANDIMPL_H_
#define _TOOLBANDIMPL_H_

#pragma once

#include <comdef.h>
#include <shlobj.h>

#include "stdafx.h"
#include <AtlApp.h>
#include <AtlWin.h>
#include <AtlCtrls.h>
#include <AtlMisc.h>
#include <AtlCrack.h>

template <class T>
class ATL_NO_VTABLE CToolBandImpl
:	public IObjectWithSite,
	public IPersistStream,
	public IDeskBand,
	public CWindowImpl<T>
{
private:
	CComPtr<IUnknown> m_spUnkSite;
	CComQIPtr<IInputObjectSite> m_spInputObjectSite;
	CWindow m_rebar;
	CToolBarCtrl m_toolbar;
	DESKBANDINFO m_dbi;

public:
	DECLARE_WND_CLASS_EX(_T("ToolBandImpl"), 0, 0)

	CToolBandImpl() { ZeroMemory(&m_dbi, sizeof m_dbi); }

	VOID SetToolBar(HWND hwnd)
	{
		m_toolbar = hwnd;
	}

	VOID SetBandInfo(DESKBANDINFO& dbi)
	{
		CopyMemory(&m_dbi, &dbi, sizeof(DESKBANDINFO));
	}

private:

// IOleObjectWithSite
	STDMETHOD(SetSite)(IUnknown* pUnkSite)
	{
		if (IsWindow()) DestroyWindow();
		m_spUnkSite.Release();

		if (pUnkSite == 0) return S_OK;

		CComQIPtr<IOleWindow> spOleWindow(pUnkSite);
		ATLASSERT(spOleWindow.p);
		if (!spOleWindow) return E_FAIL;

		HWND hwndRebar = NULL;
		spOleWindow->GetWindow(&hwndRebar);
		ATLASSERT(hwndRebar);
		if (!hwndRebar) return E_FAIL;
		m_rebar = hwndRebar;

		m_spInputObjectSite = pUnkSite;
		ATLASSERT(m_spInputObjectSite.p);
		if (!m_spInputObjectSite) return E_FAIL;

		ATLASSERT(m_rebar.IsWindow());
		Create(m_rebar, CWindow::rcDefault);
		ATLASSERT(IsWindow());
		if (!IsWindow()) return E_FAIL;

		return S_OK;
	}

	STDMETHOD(GetSite)(REFIID riid, LPVOID *ppvReturn)
	{
		*ppvReturn = NULL;

		ATLASSERT(m_spUnkSite);
		if (!m_spUnkSite) return E_FAIL;

		return m_spUnkSite->QueryInterface(riid, ppvReturn);
	}

// IPersistStream
	STDMETHOD(GetClassID)(LPCLSID pClassID)
	{
		ATLASSERT(pClassID);
		if (!pClassID) return E_POINTER;

		*pClassID = T::GetObjectCLSID();
		return S_OK;
	}

	STDMETHOD(IsDirty)(void)
	{
		return S_FALSE;
	}

	STDMETHOD(Load)(LPSTREAM /*pStream*/)
	{
		return S_OK;
	}

	STDMETHOD(Save)(LPSTREAM /*pStream*/, BOOL /*fClearDirty*/)
	{
		return S_OK;
	}

	STDMETHOD(GetSizeMax)(ULARGE_INTEGER* /*pul*/)
	{
		return E_NOTIMPL;
	}

// IDeskBand (inherits from IOleWindow and IDockingWindow)
	STDMETHOD(GetWindow)(HWND *phWnd)
	{
		ATLASSERT(IsWindow());
		if (!IsWindow()) return E_FAIL;

		*phWnd = m_hWnd;
		return S_OK;
	}


	STDMETHOD(ContextSensitiveHelp)(BOOL /*fEnterMode*/)
	{
		return E_NOTIMPL;
	}

	STDMETHOD(ShowDW)(BOOL fShow)
	{
		ATLASSERT(IsWindow());
		if (!IsWindow()) return E_FAIL;

		if(fShow) ShowWindow(SW_SHOW);
		else ShowWindow(SW_HIDE);

		return S_OK;
	}

	STDMETHOD(CloseDW)(DWORD /*dwReserved*/)
	{
		ATLASSERT(IsWindow());
		if (!IsWindow()) return E_FAIL;

		ShowDW(FALSE);
		DestroyWindow();
		return S_OK;
	}

	STDMETHOD(ResizeBorderDW)(LPCRECT, IUnknown*, BOOL)
	{
		// never called for band objects
		return E_NOTIMPL;
	}

	STDMETHOD(GetBandInfo)(DWORD /*dwBandID*/, DWORD /*dwViewMode*/, DESKBANDINFO* pdbi)
	{
		ATLASSERT(m_toolbar.IsWindow());

		if (pdbi->dwMask & DBIM_MINSIZE)   pdbi->ptMinSize = m_dbi.ptMinSize;
		if (pdbi->dwMask & DBIM_MAXSIZE)   pdbi->ptMaxSize = m_dbi.ptMaxSize;
		if (pdbi->dwMask & DBIM_INTEGRAL)  pdbi->ptIntegral = m_dbi.ptIntegral;
		if (pdbi->dwMask & DBIM_ACTUAL)    pdbi->ptActual = m_dbi.ptActual;
		if (pdbi->dwMask & DBIM_TITLE)     ocscpy(pdbi->wszTitle, m_dbi.wszTitle);
		if (pdbi->dwMask & DBIM_MODEFLAGS) pdbi->dwModeFlags = m_dbi.dwModeFlags;
		if (pdbi->dwMask & DBIM_BKCOLOR)   pdbi->dwMask &= ~DBIM_BKCOLOR;

		return S_OK;
	}

};

#endif
