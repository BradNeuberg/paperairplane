package com.ecyrd.jspwiki.providers;

import com.ecyrd.jspwiki.WikiException;

public class ProviderException
    extends WikiException
{
    public ProviderException( String msg )
    {
        super( msg );
    }
}
