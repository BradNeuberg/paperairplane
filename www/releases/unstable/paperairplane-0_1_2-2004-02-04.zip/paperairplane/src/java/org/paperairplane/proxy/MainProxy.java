package org.paperairplane.proxy;

/* - ***** BEGIN LICENSE BLOCK *****
   - Version: MPL 1.1/GPL 2.0/LGPL 2.1
   -
   - The contents of this file are subject to the Mozilla Public License Version
   - 1.1 (the "License"); you may not use this file except in compliance with
   - the License. You may obtain a copy of the License at
   - http://www.mozilla.org/MPL/
   -
   - Software distributed under the License is distributed on an "AS IS" basis,
   - WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
   - for the specific language governing rights and limitations under the
   - License.
   -
   - The Original Code is from Paper Airplane (http://www.paperairplane.us)
   -
   - The Initial Developer of the Original Code is Brad Neuberg.
   - Portions created by the Initial Developer are Copyright (C) 2003
   - the Initial Developer. All Rights Reserved.
   -
   - Contributor(s):
   -
   - Alternatively, the contents of this file may be used under the terms of
   - either the GNU General Public License Version 2 or later (the "GPL"), or
   - the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
   - in which case the provisions of the GPL or the LGPL are applicable instead
   - of those above. If you wish to allow use of your version of this file only
   - under the terms of either the GPL or the LGPL, and not to allow others to
   - use your version of this file under the terms of the MPL, indicate your
   - decision by deleting the provisions above and replace them with the notice
   - and other provisions required by the LGPL or the GPL. If you do not delete
   - the provisions above, a recipient may use your version of this file under
   - the terms of any one of the MPL, the GPL or the LGPL.
   -
   - ***** END LICENSE BLOCK *****
   */

import java.io.*;
import java.net.*;

import org.mortbay.util.*;
import org.mortbay.http.*;
import org.mortbay.jetty.*;
import org.mortbay.jetty.servlet.*;
import org.mortbay.http.handler.*;
import org.mortbay.servlet.*; 

/** This class tests setting up a peer-to-peer web server. */

public class MainProxy {
  public static int PROXY_PORT = 7474;

	public MainProxy() {
		System.out.println("initializing...");
		MainProxy.main(null);
	}

  public static void main(String args[]) {
	try {	
		// Create the server
		Server server = new Server();
     
		// Create a port listener
		System.out.println("Starting local proxy...");
		SocketListener listener=new SocketListener();
		listener.setInetAddress(InetAddress.getLocalHost());
		listener.setPort(PROXY_PORT);
		server.addListener(listener);

		// Create a context
		HttpContext context = new HttpContext();
		context.setContextPath("/");
		server.addContext(context);
     
		// Create a servlet container
		ServletHandler servlets = new ServletHandler();
		context.addHandler(servlets);

		// Map a servlet onto the container
		servlets.addServlet("MainServlet","/MainServlet/*","org.paperairplane.proxy.MainServlet");

		// Start the http server
		server.start();
		System.out.println("Local proxy started...");

	}
	catch (Exception e) {
		e.printStackTrace();
	}
  }
}