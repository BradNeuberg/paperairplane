#ifndef __IEBAR_H_
#define __IEBAR_H_

#include "resource.h"       // main symbols
#include "ToolBandImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CIEBar

// 2ECB7FB2-0333-416F-92FD-4904AD49252B
DEFINE_GUID(CLSID_IEBar, 0x2ECB7FB2,0x0333,0x416F,0x92,0xFD,0x49,0x04,0xAD,0x49,0x25,0x2B);

class ATL_NO_VTABLE CIEBar : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIEBar, &CLSID_IEBar>,
	public CToolBandImpl<CIEBar>
{
public:

DECLARE_REGISTRY_RESOURCEID(IDR_IEBAR)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIEBar)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IPersistStream)
	COM_INTERFACE_ENTRY(IDeskBand)
END_COM_MAP()

BEGIN_MSG_MAP_EX(CIEBar)
	MSG_WM_CREATE(OnCreate)
	MSG_WM_COMMAND(OnCommand)
	NOTIFY_CODE_HANDLER(TTN_NEEDTEXT, OnNeedText)
END_MSG_MAP()

	enum { CXIMAGE = 16 };

	LRESULT OnCreate(LPCREATESTRUCT pcs);
	LRESULT OnCommand(UINT nCode, UINT nID, HWND hwndCtrl);
	LRESULT OnNeedText(INT idCtrl, LPNMHDR pnmh, BOOL& bHandled);

};

#endif //__IEBAR_H_
