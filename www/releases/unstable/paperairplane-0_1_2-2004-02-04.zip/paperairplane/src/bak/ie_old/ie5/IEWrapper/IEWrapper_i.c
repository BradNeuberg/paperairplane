/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Dec 01 03:48:50 2003
 */
/* Compiler settings for C:\paperairplane\src\ie5\IEWrapper\IEWrapper.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IPaperAirplaneToolbar = {0x2B49C0FF,0xCD35,0x4AFF,{0xB5,0x3A,0x34,0xD9,0x1F,0x31,0xD1,0xF1}};


const IID LIBID_IEWRAPPERLib = {0x9B6E0704,0x584B,0x4817,{0x8E,0xEA,0xE4,0x12,0xF8,0xB8,0xA9,0xE6}};


const CLSID CLSID_PaperAirplaneToolbar = {0x69D982BB,0x4994,0x47E7,{0xA9,0x96,0xDA,0xCE,0x2D,0xF7,0x57,0x87}};


#ifdef __cplusplus
}
#endif

