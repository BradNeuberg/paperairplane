
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Sat Dec 29 14:55:13 2001
 */
/* Compiler settings for F:\Projects\ieband\ieband.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ieband_h__
#define __ieband_h__

/* Forward Declarations */ 

#ifndef __IIEBar_FWD_DEFINED__
#define __IIEBar_FWD_DEFINED__
typedef interface IIEBar IIEBar;
#endif 	/* __IIEBar_FWD_DEFINED__ */


#ifndef __IEBar_FWD_DEFINED__
#define __IEBar_FWD_DEFINED__

#ifdef __cplusplus
typedef class IEBar IEBar;
#else
typedef struct IEBar IEBar;
#endif /* __cplusplus */

#endif 	/* __IEBar_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IIEBar_INTERFACE_DEFINED__
#define __IIEBar_INTERFACE_DEFINED__

/* interface IIEBar */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IIEBar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("232E84B1-7734-4AD2-B222-5BDE9FC867C3")
    IIEBar : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IIEBarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IIEBar __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IIEBar __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IIEBar __RPC_FAR * This);
        
        END_INTERFACE
    } IIEBarVtbl;

    interface IIEBar
    {
        CONST_VTBL struct IIEBarVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIEBar_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIEBar_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIEBar_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IIEBar_INTERFACE_DEFINED__ */



#ifndef __IEBANDLib_LIBRARY_DEFINED__
#define __IEBANDLib_LIBRARY_DEFINED__

/* library IEBANDLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_IEBANDLib;

EXTERN_C const CLSID CLSID_IEBar;

#ifdef __cplusplus

class DECLSPEC_UUID("2ECB7FB2-0333-416F-92FD-4904AD49252B")
IEBar;
#endif
#endif /* __IEBANDLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


