//StockBar.cpp : Implementation of CStockBar

//***************************************************************************//
//                                                                           //
//  This file was created using the DeskBand ATL Object Wizard 2.0           //
//  By Erik Thompson � 2001                                                  //
//  Email questions and comments to erikt@radbytes.com						 //
//                                                                           //
//***************************************************************************//

#include "stdafx.h"
#include <wchar.h>
#include "MotleyFool.h"
#include "StockBar.h"

const WCHAR TITLE_CStockBar[] = L"The Motley Fool";

/////////////////////////////////////////////////////////////////////////////
// CStockBar

CStockBar::CStockBar(): 
	m_dwBandID(0), 
	m_dwViewMode(0), 
	m_bShow(FALSE), 
	m_bEnterHelpMode(FALSE), 
	m_hWndParent(NULL), 
	m_pSite(NULL)
{
	m_ReflectWnd.GetToolBar().GetEditBox().SetBand(this);
}

BOOL CStockBar::RegisterAndCreateWindow()
{
	// old RegisterAndCreateWindow before we copied stuff over from WebBand,
	// bkn3@columbia.edu
	/*RECT rect;
	::GetClientRect(m_hWndParent, &rect);
	m_ReflectWnd.Create(m_hWndParent, rect, NULL, WS_CHILD);
	// The toolbar is the window that the host will be using so it is the window that is important.
	return m_ReflectWnd.GetToolBar().IsWindow();*/

	// new RegisterAndCreateWindow, bkn3@columbia.edu
	   // If the window doesn't exist yet, create it now.
   if (!_hWnd)
   {
      // Can't create a child window without a parent.
      if (!m_hWndParent)
         return FALSE;

      // If the window class has not been registered, then do so.
      WNDCLASS wc;
      if (!GetClassInfo(g_hInst, TEXT("StockBarClass"), &wc))
      {
         ZeroMemory(&wc, sizeof(wc));
         wc.style          = CS_HREDRAW | CS_VREDRAW | CS_GLOBALCLASS;
         wc.lpfnWndProc    = (WNDPROC)MainWndProc;
         wc.cbClsExtra     = 0;
         wc.cbWndExtra     = 0;
         wc.hInstance      = g_hInst;
         wc.hIcon          = NULL;
         wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
         wc.hbrBackground  = NULL;
         wc.lpszMenuName   = NULL;
         wc.lpszClassName  = TEXT("StockBarClass");
      
         if (!RegisterClass(&wc))
         {
            // If RegisterClass fails, CreateWindow below will fail.
         }
      }

      RECT rc;
      GetClientRect(_hWnd, &rc);

      // Create the window. The WndProc will set _hWnd.
      CreateWindowEx(0,
                     TEXT("StockBarClass"),
                     NULL,
                     WS_CHILD | WS_CLIPSIBLINGS | WS_BORDER,
                     rc.left,
                     rc.top,
                     rc.right - rc.left,
                     rc.bottom - rc.top,
                     _hwndParent,
                     NULL,
                     g_hInst,
                     (LPVOID)this);
   }

   return (NULL != _hWnd);
}

// IDeskBand
STDMETHODIMP CStockBar::GetBandInfo(DWORD dwBandID, DWORD dwViewMode, DESKBANDINFO* pdbi)
{
	m_dwBandID = dwBandID;
	m_dwViewMode = dwViewMode;

	if (pdbi)
	{
		if (pdbi->dwMask & DBIM_MINSIZE)
		{
			//pdbi->ptMinSize.x = 250;
			//pdbi->ptMinSize.y = 22;
			pdbi->ptMinSize.x = 1000;
			pdbi->ptMinSize.y = 41;
		}
		if (pdbi->dwMask & DBIM_MAXSIZE)
		{
			pdbi->ptMaxSize.x = 0; // ignored
			//pdbi->ptMaxSize.y = -1;	// width
			pdbi->ptMaxSize.y = 41;
		}
		if (pdbi->dwMask & DBIM_INTEGRAL)
		{
			pdbi->ptIntegral.x = 0; // ignored
			pdbi->ptIntegral.y = 0; // not sizeable
		}
		if (pdbi->dwMask & DBIM_ACTUAL)
		{
			//pdbi->ptActual.x = 250;
			//pdbi->ptActual.y = 22;
			pdbi->ptActual.x = 1000;
			pdbi->ptActual.y = 41;
		}
		if (pdbi->dwMask & DBIM_TITLE)
		{
			wcscpy(pdbi->wszTitle, TITLE_CStockBar);
		}
		if (pdbi->dwMask & DBIM_BKCOLOR)
		{
			//Use the default background color by removing this flag.
			pdbi->dwMask &= ~DBIM_BKCOLOR;
		}
		if (pdbi->dwMask & DBIM_MODEFLAGS)
		{
			//pdbi->dwModeFlags = DBIMF_VARIABLEHEIGHT;
		}
	}
	return S_OK;
}

// IOleWindow
STDMETHODIMP CStockBar::GetWindow(HWND* phwnd)
{
	HRESULT hr = S_OK;
	if (NULL == phwnd)
	{
		hr = E_INVALIDARG;
	}
	else
	{
		*phwnd = m_ReflectWnd.GetToolBar().m_hWnd;
	}
	return hr;
}

STDMETHODIMP CStockBar::ContextSensitiveHelp(BOOL fEnterMode)
{
	m_bEnterHelpMode = fEnterMode;
	return S_OK;
}


// bkn3@columbia.edu
// IOleControlSite Methods

STDMETHODIMP CStockBar::SaveObject()
{
   return E_NOTIMPL;
}

STDMETHODIMP CStockBar::GetMoniker(DWORD dwAssign, DWORD dwWhichMoniker, LPMONIKER* ppmk)
{
   return E_NOTIMPL;
}

STDMETHODIMP CStockBar::GetContainer(LPOLECONTAINER* ppContainer)
{
    *ppContainer = NULL;       
    return E_NOINTERFACE;
}

STDMETHODIMP CStockBar::ShowObject()
{
   return S_OK;
}

STDMETHODIMP CStockBar::OnShowWindow(BOOL fShow)
{
   return S_OK;
}

STDMETHODIMP CStockBar::RequestNewObjectLayout()
{
   return E_NOTIMPL;
}

// IDockingWindow
STDMETHODIMP CStockBar::CloseDW(unsigned long dwReserved)
{
	ShowDW(FALSE);
	return S_OK;
}

STDMETHODIMP CStockBar::ResizeBorderDW(const RECT* prcBorder, IUnknown* punkToolbarSite, BOOL fReserved)
{
	// Not used by any band object.
	return E_NOTIMPL;
}

STDMETHODIMP CStockBar::ShowDW(BOOL fShow)
{
	m_bShow = fShow;
	m_ReflectWnd.GetToolBar().ShowWindow(m_bShow ? SW_SHOW : SW_HIDE);
	return S_OK;
}

// IObjectWithSite
STDMETHODIMP CStockBar::SetSite(IUnknown* pUnkSite)
{
	HRESULT hr;
    //If a site is being held, release it.
	if(m_pSite)
	{
		m_ReflectWnd.GetToolBar().SetBrowser(NULL);
		m_pSite->Release();
		m_pSite = NULL;
	}

	//If punkSite is not NULL, a new site is being set.
	if(pUnkSite)
	{
		//Get the parent window.
		IOleWindow  *pOleWindow = NULL;

		m_hWndParent = NULL;

		if(SUCCEEDED(pUnkSite->QueryInterface(IID_IOleWindow, (LPVOID*)&pOleWindow)))
		{
			pOleWindow->GetWindow(&m_hWndParent);
			pOleWindow->Release();
		}

		if(!::IsWindow(m_hWndParent))
			return E_FAIL;

		if(!RegisterAndCreateWindow())
			return E_FAIL;

		//Get and keep the IInputObjectSite pointer.
		if(FAILED(pUnkSite->QueryInterface(IID_IInputObjectSite, (LPVOID*)&m_pSite)))
		{
			return E_FAIL;
		}  

		IWebBrowser2* s_pFrameWB = NULL;
		IOleCommandTarget* pCmdTarget = NULL;
		hr = pUnkSite->QueryInterface(IID_IOleCommandTarget, (LPVOID*)&pCmdTarget);
		if (SUCCEEDED(hr))
		{
			IServiceProvider* pSP;
			hr = pCmdTarget->QueryInterface(IID_IServiceProvider, (LPVOID*)&pSP);

			pCmdTarget->Release();

			if (SUCCEEDED(hr))
			{
				hr = pSP->QueryService(SID_SWebBrowserApp, IID_IWebBrowser2, (LPVOID*)&s_pFrameWB);
				pSP->Release();
				_ASSERT(s_pFrameWB);
				m_ReflectWnd.GetToolBar().SetBrowser(s_pFrameWB);
				s_pFrameWB->Release();
			}
		}
	}

	// new stuff, bkn3@columbia.edu
	// Create and initialize the WebBrowser control that we are hosting.
    hr = CoCreateInstance(CLSID_WebBrowser, NULL, CLSCTX_INPROC,
                            IID_IOleObject, (LPVOID*)&_pIOleObject);
    if (hr != S_OK)
       return E_FAIL;

    if (_pIOleObject->SetClientSite(this) != S_OK)
       return E_FAIL;

    // Get the rectangle of the client area
    RECT rcClient = { CW_USEDEFAULT, 0, 0, 0 };
    GetClientRect(_hWnd, &rcClient);

    MSG msg;

    // In-place activate the WebBrowser control
    hr = _pIOleObject->DoVerb(OLEIVERB_INPLACEACTIVATE, &msg,
                              this, 0, _hWnd, &rcClient);
    _ASSERT(SUCCEEDED(hr));

    if (FAILED(hr))
       return E_FAIL;

	//
    // Get the pointer to the WebBrowser control. 
    //
    hr = _pIOleObject->QueryInterface(IID_IWebBrowser2,
                                      (LPVOID*)&_pWebBrowserOC);
    _ASSERT(_pWebBrowserOC);

    if (FAILED(hr))
       return E_FAIL;
    else
    {
	   // bkn3@columbia.edu - I don't think we need these
       // Set up an event sink for the WebBrowser events
       //if (_pWebBrowserOC)
       //   AdviseWBEventSink();

	   //
       // QI for the in-place object to set the size.
       //
       if (_pIOleIPObject)
       {
          _pIOleIPObject->Release();
          _pIOleIPObject = NULL;
       }

       hr = _pWebBrowserOC->QueryInterface(IID_IOleInPlaceObject,
                                           (LPVOID*)&_pIOleIPObject);
       _ASSERT(_pIOleIPObject);

       if (FAILED(hr))
          return E_FAIL;

       hr = _pIOleIPObject->SetObjectRects(&rcClient, &rcClient);
       _ASSERT(SUCCEEDED(hr));

       // Navigate to the sample search page
       _variant_t vtEmpty;
       _bstr_t bstrURL("http://www.mozilla.org");

       _pWebBrowserOC->Navigate(bstrURL, &vtEmpty, &vtEmpty,
                                &vtEmpty, &vtEmpty);

       // Get the HWND of the WebBrowser OC
       //
       IOleWindow* pWnd;

       if (SUCCEEDED(_pWebBrowserOC->QueryInterface(IID_IOleWindow,
                                                    (LPVOID*)&pWnd)))
       {
          pWnd->GetWindow(&_hwndWB);
       }
   }

   return S_OK;
}

STDMETHODIMP CStockBar::GetSite(REFIID riid, void **ppvSite)
{
	*ppvSite = NULL;

	if(m_pSite)
	{
	   return m_pSite->QueryInterface(riid, ppvSite);
	}
	return E_FAIL;
}

void CStockBar::FocusChange(BOOL bHaveFocus)
{
	if (m_pSite)
	{
		IUnknown* pUnk = NULL;
		if (SUCCEEDED(QueryInterface(IID_IUnknown, (LPVOID*)&pUnk)) && pUnk != NULL)
		{
			m_pSite->OnFocusChangeIS(pUnk, bHaveFocus);
			pUnk->Release();
			pUnk = NULL;
		}
	}
}

STDMETHODIMP CStockBar::HasFocusIO(void)
{
	// if any of the windows in our toolbar have focus then return S_OK else S_FALSE.
	if (m_ReflectWnd.GetToolBar().m_hWnd == ::GetFocus())
		return S_OK;
	if (m_ReflectWnd.GetToolBar().GetEditBox().m_hWnd == ::GetFocus())
		return S_OK;
	return S_FALSE;
}
STDMETHODIMP CStockBar::TranslateAcceleratorIO(LPMSG lpMsg)
{
	// the only window that needs to translate messages is our edit box so forward them.
	return m_ReflectWnd.GetToolBar().GetEditBox().TranslateAcceleratorIO(lpMsg);
}
STDMETHODIMP CStockBar::UIActivateIO(BOOL fActivate, LPMSG lpMsg)
{
	// if our deskband is being activated then set focus to the edit box.
	if(fActivate)
	{
		m_ReflectWnd.GetToolBar().GetEditBox().SetFocus();
	}
	return S_OK;
}
