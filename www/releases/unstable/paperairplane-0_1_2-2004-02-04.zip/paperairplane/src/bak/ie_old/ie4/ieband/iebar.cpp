//	THIS CODE IS EXPERIMENTAL.  IT WORKS, BUT DON'T RELY ON IT.
//	tltabor@earthlink.net

// IEBar.cpp : Implementation of CIEBar
#include "stdafx.h"
#include "ieband.h"
#include "IEBar.h"

#define TBSTYLE   0x5600894d
#define TBEXSTYLE 0x00000080
/////////////////////////////////////////////////////////////////////////////
// CIEBar

LRESULT CIEBar::OnCreate(LPCREATESTRUCT pcs)
{
	// create the toolbar
	ATLASSERT(IsWindow());
	if (!IsWindow()) return -1;

	CToolBarCtrl toolbar;
	toolbar.Create(m_hWnd, NULL, NULL, TBSTYLE, TBEXSTYLE);
	ATLASSERT(toolbar.m_hWnd);
	if (!toolbar.m_hWnd) return -1;

	CImageList ilCool;
	ilCool.CreateFromImage(IDB_COOL, CXIMAGE, 0, CLR_DEFAULT, 0);
	ATLASSERT(ilCool.m_hImageList);
	if (!ilCool.m_hImageList) return -1;
	toolbar.SetImageList(ilCool);
	
	CImageList ilHot;
	ilHot.CreateFromImage(IDB_HOT, CXIMAGE, 0, CLR_DEFAULT, 0);
	ATLASSERT(ilHot.m_hImageList);
	if (!ilHot.m_hImageList) return -1;
	toolbar.SetHotImageList(ilHot);

	toolbar.SetButtonStructSize(sizeof(TBBUTTON));
	INT nButtons = ID_BLUE - ID_RED + 1;
	for (INT i = 0; i < nButtons; i++){
		TBBUTTON tbb = {0};
		tbb.iBitmap = i;
		tbb.idCommand = ID_RED + i;
		tbb.fsState = TBSTATE_ENABLED;
		tbb.fsStyle = TBSTYLE_NOPREFIX;
		BOOL b = toolbar.AddButtons(1, &tbb);
		ATLASSERT(b);
		if (!b) return FALSE;
	}

	// calculate ieband info
	DESKBANDINFO dbi={0};
	CRect r;
	toolbar.GetItemRect(nButtons-1, &r);
	AdjustWindowRect(&r, toolbar.GetStyle(), FALSE);
	toolbar.MoveWindow(0, 0, r.right, r.Height());
	AdjustWindowRect(&r, GetStyle(), FALSE);

	// set width long enough to ensure the rebar will break for this band
	// unlike rebarbands, deskbands don't have an RBBS_BREAK style 
	dbi.ptMinSize.x = dbi.ptMaxSize.x = dbi.ptActual.x = 1024;
	dbi.ptMinSize.y = dbi.ptMaxSize.y = dbi.ptActual.y = r.Height();
	ocscpy(dbi.wszTitle, L"iebar");
	dbi.dwModeFlags = DBIMF_NORMAL; 

	// pass info to CToolBandImpl
	SetToolBar(toolbar);
	SetBandInfo(dbi);

	return 0;
}

LRESULT CIEBar::OnCommand(UINT nCode, UINT nID, HWND hwndCtrl)
{
	CString strMsg, strTitle;
	strMsg.LoadString(nID);
	strTitle.LoadString(IDS_PROJNAME);
	if (strMsg.GetLength() != 0) MessageBox(strMsg, strTitle);

	return 0;
}

LRESULT CIEBar::OnNeedText(INT idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	if (idCtrl < ID_RED || idCtrl > ID_BLUE)
	{
		bHandled = FALSE;
		return 0;
	}

	LPNMTTDISPINFO pttdi = (LPNMTTDISPINFO)pnmh;

	pttdi->lpszText = MAKEINTRESOURCE(idCtrl);
	pttdi->hinst = _Module.GetResourceInstance();
	pttdi->uFlags = TTF_DI_SETITEM;

	return 0;
}

