/** Modified by Brad Neuberg, bkn3@columbia.edu, to enable installation to block until the JRE is finished being
    installed. */

// this function verifies disk space in kilobytes
function verifyDiskSpace(dirPath, spaceRequired)
{
  var spaceAvailable;

  // Get the available disk space on the given path
  spaceAvailable = fileGetDiskSpaceAvailable(dirPath);

  // Convert the available disk space into kilobytes
  spaceAvailable = parseInt(spaceAvailable / 1024);

  // do the verification
  if(spaceAvailable < spaceRequired)
  {
    logComment("Insufficient disk space: " + dirPath);
    logComment("  required : " + spaceRequired + " K");
    logComment("  available: " + spaceAvailable + " K");
    return(false);
  }

  return(true);
}

// main
var err;
var tempDir = getFolder("Temporary");

//This version is JRE 1.4.1.02

err    = initInstall("Sun Java 2", "/Sun/Java 2", "1.4.1.2"); 
logComment("initInstall() returned: " + err);

addFile("Sun Java 2", "j2re-1_4_1_02-windows-i586.exe", tempDir, null);
addFile("Sun Java 2", "setup.iss", tempDir, null);
addFile("Sun Java 2", "ConfigureJRE.class", tempDir, null);
addFile("Sun Java 2", "grep.exe", tempDir, null);
err = getLastError();
logComment("results of extracting j2re-1_4_1_02-windows-i586.exe, grep.exe, setup.iss, and ConfigureJRE.class:" + err);

// this script executes the JRE installer, blocks until its down, and then cleans up any temporary files
err = execute("install-jre.bat", "", true);
//err = execute("j2re-1_4_1_02-windows-i586.exe", "-s -a -s -f1 setup.iss", true);

//noisy install
//err = execute("j2re-1_4_1_01-windows-i586-i.exe");

logComment("execute() returned: " + err);

if(!err)
{
  err = performInstall(); 
  logComment("performInstall() returned: " + err);
}

// end main

