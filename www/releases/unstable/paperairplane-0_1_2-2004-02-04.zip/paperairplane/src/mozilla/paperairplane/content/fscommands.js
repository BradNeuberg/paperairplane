

/** Funnel file specific DoFSCommands to our general DoFSCommand. */
function mainToolbar_DoFSCommand(command, parameters) {
	DoFSCommand(command, parameters);
	
}

/** Funnel file specific DoFSCommands to our general DoFSCommand. */
function signOnDialog_DoFSCommand(command, parameters) {
	DoFSCommand(command, parameters);
}

/** Our main DoFSCommand. */
function DoFSCommand(command, parameters) {
	if (command == "java" && parameters == "initialize") {
		alert("Initializing java...");
		Packages.java.lang.System.out.println("test");
		Packages.org.paperairplane.proxy.MainProxy.main("");
		alert("finished");
	}
}