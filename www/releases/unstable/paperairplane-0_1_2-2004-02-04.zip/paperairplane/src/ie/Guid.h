/////////////////////////////////////////////////////////////////////////////
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright 1998 Microsoft Corporation.  All Rights Reserved.
//
// Author: Scott Roberts, Microsoft Developer Support - Internet Client SDK  
//
// Portions of this code were taken from the bandobj sample that comes
// with the Internet Client SDK for Internet Explorer 4.0x
//
//
// Guid.h - Private GUID definition.
/////////////////////////////////////////////////////////////////////////////

#ifndef __Guid_h__
#define __Guid_h__

// {CA606B66-C131-4aa2-8B3F-D4C9619A7F48}
DEFINE_GUID(CLSID_WBExplorerBar, 
0xca606b66, 0xc131, 0x4aa2, 0x8b, 0x3f, 0xd4, 0xc9, 0x61, 0x9a, 0x7f, 0x48);

static const char * CLSID_WBExplorerBar_Registry = TEXT("{CA606B66-C131-4aa2-8B3F-D4C9619A7F48}");

// {8F066431-14CB-4ab7-9A53-944CF905316D}
DEFINE_GUID(CLSID_WebBandButton, 
0x8f066431, 0x14cb, 0x4ab7, 0x9a, 0x53, 0x94, 0x4c, 0xf9, 0x5, 0x31, 0x6d);

static const char * CLSID_WebBandButton_Registry = TEXT("{8F066431-14CB-4ab7-9A53-944CF905316D}");


#endif // __Guid_h__